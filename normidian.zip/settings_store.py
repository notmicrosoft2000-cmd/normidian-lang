"""
settings_store.py
===================
Small local-only settings file (NOT synced to GitHub -- these are
per-machine UI preferences, not language data). Stored as JSON next to
the app in normidian_settings.json.

Kept intentionally tiny and dependency-free so both translator_app.py
and dictionary_manager.py can share one Settings dialog and one source
of truth for "how the app looks/behaves on this machine".
"""

import json
import os

SETTINGS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "normidian_settings.json")

DEFAULTS = {
    "font_scale": 1.0,          # multiplier applied to base font sizes
    "animations_enabled": True,  # hover fades / card slide in-out
    "auto_read_aloud": False,   # speak the output automatically after translating
    "tts_rate": 175,            # words per minute, passed to pyttsx3
    "default_direction": "en_to_no",   # "en_to_no" or "no_to_en"
    "target_language": "en",    # ISO code Normidian output is bridged to (via English)
    "high_contrast": False,     # thicker borders / higher-contrast focus rings
}

FONT_SCALE_CHOICES = [("Small", 0.85), ("Medium", 1.0), ("Large", 1.15), ("Extra Large", 1.3)]

# A modest set of common target languages for the Normidian -> Other
# Language bridge (Normidian -> English -> target, via translate_service).
BRIDGE_LANGUAGES = [
    ("English", "en"), ("Spanish", "es"), ("French", "fr"), ("German", "de"),
    ("Italian", "it"), ("Portuguese", "pt"), ("Dutch", "nl"), ("Russian", "ru"),
    ("Japanese", "ja"), ("Chinese (Simplified)", "zh"), ("Korean", "ko"),
    ("Arabic", "ar"), ("Hindi", "hi"),
]


def load():
    data = dict(DEFAULTS)
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            saved = json.load(f)
        if isinstance(saved, dict):
            data.update({k: v for k, v in saved.items() if k in DEFAULTS})
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return data


def save(settings):
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump({k: settings.get(k, v) for k, v in DEFAULTS.items()}, f, indent=2)
        return True
    except OSError:
        return False
