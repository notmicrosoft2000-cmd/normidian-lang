"""
config.py
==========
Loads GitHub credentials/configuration from environment variables.

Set these before running either app. See the setup guide for exact
commands on Windows/macOS/Linux.

    GITHUB_TOKEN   Personal Access Token with 'repo' scope
    REPO_NAME      "yourusername/your-repo-name"
    GITHUB_BRANCH  branch to read/write (optional, defaults to "main")

This module intentionally does not hard-code any credentials. If a value
is missing, cloud_sync.py will raise a clear error the first time it's
actually needed (at fetch/push time), rather than crashing at import time
-- so the GUI can start and show a friendly message instead of a stack
trace before a window even appears.
"""

import os

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "").strip()
REPO_NAME = os.environ.get("REPO_NAME", "").strip()
BRANCH = os.environ.get("GITHUB_BRANCH", "main").strip() or "main"


def is_configured():
    """Quick check used by the GUIs to show a setup warning banner."""
    return bool(GITHUB_TOKEN) and bool(REPO_NAME)


def missing_fields():
    """Return a list of which required env vars are missing, for messaging."""
    missing = []
    if not GITHUB_TOKEN:
        missing.append("GITHUB_TOKEN")
    if not REPO_NAME:
        missing.append("REPO_NAME")
    return missing
