#!/usr/bin/env python3
"""
translator_app.py
====================
Standalone desktop app (Tkinter, not a browser) for translating between
English and Normidian. This app is completely READ-ONLY with respect to
the dictionary: it has no add/edit/delete controls anywhere. It only
fetches the dictionary once at launch (cached in memory) and a manual
"Refresh" button to re-pull the latest version from GitHub if the
Dictionary Manager has been used to add new words since this app started.

Layout: a Translator tab (English/Normidian input & output, a settings
sidebar with direction + word order + color-grammar toggle + a live
"processed / unknown" word list, plus a swap-direction button), a
Dictionary tab (read-only search/browse of the synced vocabulary --
click any word to try it in the Translator tab), a Grammar Guide tab,
and a Cheat Sheet tab with quick-reference tables.

Capitalized words with no dictionary entry (e.g. "John") are treated as
proper nouns/names and passed through untranslated in both directions,
rather than being flagged as unknown -- see
NormidianEngine.is_probable_proper_noun for the heuristic and its
caveats.

Typing triggers a debounced real-time translation (no button), with a
small fading-pulse animation shown while translation is "computing"
(i.e. during the debounce window), rather than the output flashing
instantly on every keystroke.

Run with:  python translator_app.py
Requires:  GITHUB_TOKEN and REPO_NAME environment variables to be set
           (see the setup guide).
"""

import sys

if sys.platform.startswith("win"):
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            import ctypes
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

import tkinter as tk
from tkinter import ttk, messagebox

import config
import cloud_sync
import settings_store
import translate_service
from normidian_engine import NormidianEngine
from colorizer import colorize_english, colorize_normidian
from grammar import ALL_WORD_CATEGORIES, SPECIAL_CHARS
from theme import (
    COLOR_BG, COLOR_PANEL, COLOR_FIELD, COLOR_TEXT, COLOR_TEXT_MUTED,
    COLOR_ACCENT, COLOR_ACCENT_HOVER, COLOR_BORDER, COLOR_DANGER,
    COLOR_SUCCESS, COLOR_OUTPUT_BG, COLOR_OUTPUT_TEXT, FONT_FAMILY, FONT_MONO,
    POS_COLORS, POS_LABELS,
)
from widgets import HoverButton, FadeEntry, FadeCard, SpecialCharKeyboard, Tooltip, RoundedPanel, set_animations_enabled
from settings_dialog import SettingsDialog

REALTIME_DEBOUNCE_MS = 450
PULSE_STEPS = 14
PULSE_STEP_MS = 45  # one fade-in-fade-out pulse cycle while "computing"

ALL_CATEGORIES = ALL_WORD_CATEGORIES

SPECIAL_CHAR_TIPS = {
    "ð": "eth (Ð/ð) -- voiced 'th', as in this",
    "þ": "thorn (Þ/þ) -- unvoiced 'th', as in thin",
    "ƿ": "wynn (Ƿ/ƿ) -- pronounced like 'w'",
    "œ": "oe (Œ/œ) -- strong-verb vowel shift from a/e/i",
    "æ": "ash (Æ/æ) -- strong-verb vowel shift from o/u",
}

try:
    import pyttsx3
    PYTTSX3_AVAILABLE = True
except Exception:
    PYTTSX3_AVAILABLE = False


class TranslatorApp:
    def __init__(self, root):
        self.root = root
        self.dictionary = {}
        self.engine = NormidianEngine({})
        self.settings = settings_store.load()
        self.direction_var = tk.StringVar(value=self.settings.get("default_direction", "en_to_no"))
        self.word_order_var = tk.StringVar(value="SVO")
        self.color_mode_var = tk.BooleanVar(value=True)
        self.target_lang_var = tk.StringVar(value=self.settings.get("target_language", "en"))
        self._debounce_job = None
        self._pulse_job = None
        self._last_translated_raw = None
        self._last_bridged_note = ""
        self.tts_engine = None

        self._setup_window()
        self._setup_styles()
        self._build_layout()
        self._apply_settings(self.settings, initial=True)
        self._load_from_github(initial=True)

    # ------------------------------------------------------------------
    def _setup_window(self):
        self.root.title("Normidian Translator")
        self.root.configure(bg=COLOR_BG)
        self.root.geometry("1120x720")
        self.root.minsize(860, 580)

    def _setup_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TFrame", background=COLOR_BG)
        style.configure(
            "Vertical.TScrollbar", background=COLOR_PANEL, troughcolor=COLOR_BG,
            bordercolor=COLOR_BG, arrowcolor=COLOR_TEXT_MUTED,
        )
        style.configure("TCombobox", fieldbackground=COLOR_FIELD, background=COLOR_FIELD)
        style.configure("TNotebook", background=COLOR_BG, borderwidth=0)
        style.configure(
            "TNotebook.Tab", background=COLOR_PANEL, foreground=COLOR_TEXT_MUTED,
            padding=(18, 10), font=(FONT_FAMILY, 10, "bold"), borderwidth=0,
        )
        style.map(
            "TNotebook.Tab",
            background=[("selected", COLOR_ACCENT)],
            foreground=[("selected", COLOR_TEXT)],
        )
        style.configure(
            "TRadiobutton", background=COLOR_PANEL, foreground=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        )
        style.map("TRadiobutton", background=[("active", COLOR_PANEL)])

    def _build_layout(self):
        header = tk.Frame(self.root, bg=COLOR_BG)
        header.pack(fill="x", padx=24, pady=(20, 10))

        tk.Label(
            header, text="Normidian Translator", bg=COLOR_BG, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 20, "bold"),
        ).pack(side="left")

        tk.Label(
            header, text="  ·  dictionary is read-only here", bg=COLOR_BG, fg=COLOR_TEXT_MUTED,
            font=(FONT_FAMILY, 11, "italic"),
        ).pack(side="left", pady=(6, 0))

        self.sync_status_label = tk.Label(
            header, text="", bg=COLOR_BG, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 10),
        )
        self.sync_status_label.pack(side="left", padx=(16, 0), pady=(6, 0))

        gear_btn = HoverButton(
            header, text="⚙ Settings", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._open_settings,
        )
        gear_btn.pack(side="right")
        Tooltip(gear_btn, "Text size, animations, speech, default direction, and the "
                          "Normidian → other-language bridge.")

        HoverButton(
            header, text="↻ Refresh Dictionary", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=lambda: self._load_from_github(initial=False),
        ).pack(side="right", padx=(0, 8))

        if not config.is_configured():
            warn = tk.Frame(self.root, bg="#3A2400")
            warn.pack(fill="x", padx=24, pady=(0, 10))
            missing = ", ".join(config.missing_fields())
            tk.Label(
                warn, text=f"⚠ Missing environment variable(s): {missing}. "
                           f"Set them so this app can fetch the dictionary.",
                bg="#3A2400", fg="#FFD27A", font=(FONT_FAMILY, 10), anchor="w",
            ).pack(fill="x", padx=14, pady=8)

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=24, pady=(0, 20))

        self.translator_tab = tk.Frame(self.notebook, bg=COLOR_BG)
        self.dictionary_tab = tk.Frame(self.notebook, bg=COLOR_BG)
        self.grammar_tab = tk.Frame(self.notebook, bg=COLOR_BG)
        self.cheatsheet_tab = tk.Frame(self.notebook, bg=COLOR_BG)

        self.notebook.add(self.translator_tab, text="Translator")
        self.notebook.add(self.dictionary_tab, text="Dictionary")
        self.notebook.add(self.grammar_tab, text="Grammar Guide")
        self.notebook.add(self.cheatsheet_tab, text="Cheat Sheet")

        self._build_translator_tab()
        self._build_dictionary_tab()
        self._build_grammar_tab()
        self._build_cheatsheet_tab()

    # ==================================================================
    # TRANSLATOR TAB
    # ==================================================================
    def _build_translator_tab(self):
        self._build_language_bar(self.translator_tab)

        body = tk.Frame(self.translator_tab, bg=COLOR_BG)
        body.pack(fill="both", expand=True, pady=(10, 0))
        body.columnconfigure(0, weight=1)
        body.columnconfigure(1, weight=1)
        body.columnconfigure(2, weight=0)
        body.rowconfigure(0, weight=1)

        self._build_input_panel(body)
        self._build_output_panel(body)
        self._build_settings_sidebar(body)

    # ------------------------------------------------------------------
    # Google-Translate-style language bar: "English  ⇄  Normidian", plus
    # a target-language dropdown that appears only in the Normidian ->
    # English direction, letting the output bridge into a third language.
    # ------------------------------------------------------------------
    def _build_language_bar(self, parent):
        bar = RoundedPanel(parent, bg=COLOR_PANEL, height=54)
        bar.pack(fill="x", pady=(4, 0))
        bar.pack_propagate(False)
        row = bar.body
        row.configure(bg=COLOR_PANEL)

        self.source_lang_label = tk.Label(
            row, text="English", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 12, "bold"), padx=18,
        )
        self.source_lang_label.pack(side="left", pady=14)

        swap_btn = HoverButton(
            row, text="⇄", bg=COLOR_FIELD, hover_bg=COLOR_ACCENT,
            command=self._swap_direction, font=(FONT_FAMILY, 11, "bold"),
        )
        swap_btn.pack(side="left", pady=10, padx=6)
        Tooltip(swap_btn, "Swap languages and move the current output into the input box.")

        self.target_lang_label = tk.Label(
            row, text="Normidian", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 12, "bold"),
        )
        self.target_lang_label.pack(side="left", pady=14)

        # Target-language bridge dropdown -- only meaningful/visible when
        # translating out of Normidian, since that's the only direction
        # with a language beyond English to bridge into.
        self.bridge_frame = tk.Frame(row, bg=COLOR_PANEL)
        code_to_label = {code: label for label, code in settings_store.BRIDGE_LANGUAGES}
        self._bridge_display_var = tk.StringVar(
            value=code_to_label.get(self.target_lang_var.get(), "English")
        )
        bridge_dropdown = ttk.Combobox(
            self.bridge_frame, textvariable=self._bridge_display_var, state="readonly",
            values=[label for label, _ in settings_store.BRIDGE_LANGUAGES],
            font=(FONT_FAMILY, 10), width=16,
        )
        bridge_dropdown.pack(side="left", padx=(4, 14), pady=12)

        def _on_bridge_change(_e=None):
            label = self._bridge_display_var.get()
            code = next((c for l, c in settings_store.BRIDGE_LANGUAGES if l == label), "en")
            self.target_lang_var.set(code)
            self._last_translated_raw = None
            self._trigger_translate_now()
        bridge_dropdown.bind("<<ComboboxSelected>>", _on_bridge_change)
        self._update_bridge_visibility()

    def _update_bridge_visibility(self):
        if self.direction_var.get() == "no_to_en":
            self.bridge_frame.pack(side="left")
        else:
            self.bridge_frame.pack_forget()

    # ------------------------------------------------------------------
    # LEFT: input (English or Normidian, depending on direction)
    # ------------------------------------------------------------------
    def _build_input_panel(self, parent):
        panel = tk.Frame(parent, bg=COLOR_PANEL)
        panel.grid(row=0, column=0, sticky="nsew", padx=(0, 8))

        self.input_label = tk.Label(
            panel, text="English", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED,
            font=(FONT_FAMILY, 10, "bold"), anchor="w",
        )
        self.input_label.pack(fill="x", padx=14, pady=(14, 6))

        self.input_text = tk.Text(
            panel, bg=COLOR_FIELD, fg=COLOR_TEXT, insertbackground=COLOR_TEXT,
            relief="flat", font=(FONT_FAMILY, 14), wrap="word",
            padx=14, pady=12, undo=True,
        )
        self.input_text.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        self.input_text.bind("<KeyRelease>", self._on_input_key_release)
        self._configure_text_tags(self.input_text)

        self.special_kb = SpecialCharKeyboard(
            panel, targets=[self.input_text], special_chars=SPECIAL_CHARS,
        )
        self.special_kb.pack(fill="x", padx=14, pady=(0, 10))
        for child in self.special_kb.winfo_children():
            tip = SPECIAL_CHAR_TIPS.get(child["text"])
            if tip:
                Tooltip(child, tip)

        clear_row = tk.Frame(panel, bg=COLOR_PANEL)
        clear_row.pack(fill="x", padx=14, pady=(0, 14))
        HoverButton(
            clear_row, text="Clear", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._clear_input,
        ).pack(side="left")
        HoverButton(
            clear_row, text="Copy", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._copy_input,
        ).pack(side="left", padx=(8, 0))
        self.input_copied_label = tk.Label(
            clear_row, text="Copied!", bg=COLOR_PANEL, fg=COLOR_SUCCESS, font=(FONT_FAMILY, 9, "bold"),
        )

    # ------------------------------------------------------------------
    # MIDDLE: output (tinted indigo)
    # ------------------------------------------------------------------
    def _build_output_panel(self, parent):
        panel = tk.Frame(parent, bg=COLOR_OUTPUT_BG)
        panel.grid(row=0, column=1, sticky="nsew", padx=(8, 8))

        header_row = tk.Frame(panel, bg=COLOR_OUTPUT_BG)
        header_row.pack(fill="x", padx=14, pady=(14, 6))
        self.output_label = tk.Label(
            header_row, text="Normidian", bg=COLOR_OUTPUT_BG, fg=COLOR_OUTPUT_TEXT,
            font=(FONT_FAMILY, 10, "bold"), anchor="w",
        )
        self.output_label.pack(side="left")

        self.pulse_label = tk.Label(
            header_row, text="● computing", bg=COLOR_OUTPUT_BG, fg=COLOR_OUTPUT_BG,
            font=(FONT_FAMILY, 9),
        )
        self.pulse_label.pack(side="left", padx=(10, 0))

        self.output_text = tk.Text(
            panel, bg=COLOR_OUTPUT_BG, fg=COLOR_OUTPUT_TEXT, insertbackground=COLOR_OUTPUT_TEXT,
            relief="flat", font=(FONT_FAMILY, 14), wrap="word",
            padx=14, pady=12, state="disabled", cursor="arrow",
            highlightthickness=1, highlightbackground=COLOR_ACCENT, highlightcolor=COLOR_ACCENT,
        )
        self.output_text.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        self._configure_text_tags(self.output_text)

        btn_row = tk.Frame(panel, bg=COLOR_OUTPUT_BG)
        btn_row.pack(fill="x", padx=14, pady=(0, 6))
        self.copy_btn = HoverButton(
            btn_row, text="Copy", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._copy_output,
        )
        self.copy_btn.pack(side="left")
        self.tts_btn = HoverButton(
            btn_row, text="🔊 Read Aloud", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._read_aloud,
        )
        self.tts_btn.pack(side="left", padx=(8, 0))
        self.copied_label = tk.Label(
            btn_row, text="Copied!", bg=COLOR_OUTPUT_BG, fg=COLOR_SUCCESS, font=(FONT_FAMILY, 9, "bold"),
        )

        self.status_label = tk.Label(
            panel, text="", bg=COLOR_OUTPUT_BG, fg=COLOR_DANGER, font=(FONT_FAMILY, 9),
            anchor="w", justify="left", wraplength=420,
        )
        self.status_label.pack(fill="x", padx=14, pady=(0, 4))

        self.gloss_label = tk.Label(
            panel, text="", bg=COLOR_OUTPUT_BG, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 9, "italic"),
            anchor="w", justify="left", wraplength=420,
        )
        self.gloss_label.pack(fill="x", padx=14, pady=(0, 8))

        # Color legend (only meaningful when Color Grammar is on)
        self.legend_frame = tk.Frame(panel, bg=COLOR_OUTPUT_BG)
        self.legend_frame.pack(fill="x", padx=14, pady=(0, 12))
        self._build_legend(self.legend_frame)

    def _build_legend(self, parent):
        for pos_key in ("nouns_living", "nouns_dead", "verbs", "adjectives",
                        "prepositions", "adverbs", "conjunctions",
                        "article", "pronouns", "suffix"):
            chip = tk.Frame(parent, bg=COLOR_OUTPUT_BG)
            chip.pack(side="left", padx=(0, 8), pady=2)
            tk.Label(
                chip, text="●", bg=COLOR_OUTPUT_BG, fg=POS_COLORS[pos_key],
                font=(FONT_FAMILY, 10),
            ).pack(side="left")
            tk.Label(
                chip, text=POS_LABELS.get(pos_key, pos_key), bg=COLOR_OUTPUT_BG,
                fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 8),
            ).pack(side="left", padx=(2, 0))

    def _configure_text_tags(self, text_widget):
        for pos_key, color in POS_COLORS.items():
            text_widget.tag_configure(pos_key, foreground=color)

    # ------------------------------------------------------------------
    # RIGHT: Settings sidebar
    # ------------------------------------------------------------------
    def _build_settings_sidebar(self, parent):
        panel = tk.Frame(parent, bg=COLOR_PANEL, width=280)
        panel.grid(row=0, column=2, sticky="nsew")
        panel.grid_propagate(False)

        tk.Label(
            panel, text="Settings", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 13, "bold"),
        ).pack(anchor="w", padx=18, pady=(18, 10))

        tk.Label(
            panel, text="Direction:", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        ).pack(anchor="w", padx=18)
        dir_frame = tk.Frame(panel, bg=COLOR_PANEL)
        dir_frame.pack(anchor="w", padx=18, pady=(4, 12))
        tk.Radiobutton(
            dir_frame, text="English → Normidian", value="en_to_no", variable=self.direction_var,
            bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_FIELD,
            activebackground=COLOR_PANEL, activeforeground=COLOR_TEXT,
            font=(FONT_FAMILY, 9), command=self._on_direction_change,
        ).pack(anchor="w", pady=1)
        tk.Radiobutton(
            dir_frame, text="Normidian → English", value="no_to_en", variable=self.direction_var,
            bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_FIELD,
            activebackground=COLOR_PANEL, activeforeground=COLOR_TEXT,
            font=(FONT_FAMILY, 9), command=self._on_direction_change,
        ).pack(anchor="w", pady=1)

        self.order_frame = tk.Frame(panel, bg=COLOR_PANEL)
        self.order_frame.pack(anchor="w", fill="x", padx=18, pady=(0, 4))
        tk.Label(
            self.order_frame, text="Word Order:", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        ).pack(anchor="w")
        order_dropdown = ttk.Combobox(
            self.order_frame, textvariable=self.word_order_var, state="readonly",
            values=["SVO", "OSV", "VOS"], font=(FONT_FAMILY, 10), width=10,
        )
        order_dropdown.pack(anchor="w", pady=(4, 4))

        order_hint = {
            "SVO": "Subject – Verb – Object (standard)",
            "OSV": "Object – Subject – Verb (poetic)",
            "VOS": "Verb – Object – Subject",
        }
        self.order_hint_label = tk.Label(
            self.order_frame, text=order_hint["SVO"], bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED,
            font=(FONT_FAMILY, 8), wraplength=240, justify="left",
        )
        self.order_hint_label.pack(anchor="w", pady=(0, 4))

        def _update_hint(_e=None):
            self.order_hint_label.config(text=order_hint.get(self.word_order_var.get(), ""))
        order_dropdown.bind("<<ComboboxSelected>>", lambda e: (_update_hint(), self._trigger_translate_now()))

        color_frame = tk.Frame(panel, bg=COLOR_PANEL)
        color_frame.pack(anchor="w", fill="x", padx=18, pady=(6, 10))
        tk.Checkbutton(
            color_frame, text="Color Grammar", variable=self.color_mode_var,
            bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_FIELD,
            activebackground=COLOR_PANEL, activeforeground=COLOR_TEXT,
            font=(FONT_FAMILY, 9), command=self._on_color_mode_change,
        ).pack(anchor="w")

        divider = tk.Frame(panel, bg=COLOR_BORDER, height=1)
        divider.pack(fill="x", padx=18, pady=(4, 14))

        tk.Label(
            panel, text="Processed Words", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 11, "bold"),
        ).pack(anchor="w", padx=18)

        self.processed_frame = tk.Frame(panel, bg=COLOR_PANEL)
        self.processed_frame.pack(fill="x", padx=18, pady=(6, 14))

        tk.Label(
            panel, text="Unknown Words", bg=COLOR_PANEL, fg=COLOR_DANGER,
            font=(FONT_FAMILY, 11, "bold"),
        ).pack(anchor="w", padx=18)

        self.unknown_frame = tk.Frame(panel, bg=COLOR_PANEL)
        self.unknown_frame.pack(fill="x", padx=18, pady=(6, 14))

        self.negation_label = tk.Label(
            panel, text="", bg=COLOR_PANEL, fg=COLOR_ACCENT_HOVER,
            font=(FONT_FAMILY, 9, "italic"), wraplength=240, justify="left",
        )
        self.negation_label.pack(anchor="w", padx=18, pady=(0, 10))

    # ------------------------------------------------------------------
    # Direction / color-mode switching
    # ------------------------------------------------------------------
    def _on_direction_change(self, preserve_text=None):
        if self.direction_var.get() == "en_to_no":
            self.input_label.config(text="English")
            self.output_label.config(text="Normidian")
            self.source_lang_label.config(text="English")
            self.target_lang_label.config(text="Normidian")
            self.order_frame.pack(anchor="w", fill="x", padx=18, pady=(0, 4))
        else:
            self.input_label.config(text="Normidian")
            code_to_label = {code: label for label, code in settings_store.BRIDGE_LANGUAGES}
            out_label = code_to_label.get(self.target_lang_var.get(), "English")
            self.output_label.config(text=out_label)
            self.source_lang_label.config(text="Normidian")
            self.target_lang_label.config(text=out_label)
            self.order_frame.pack_forget()
        self._update_bridge_visibility()
        self._clear_input()
        if preserve_text:
            self.input_text.insert("1.0", preserve_text)
            self._trigger_translate_now()

    def _on_color_mode_change(self):
        self._last_translated_raw = None
        self._trigger_translate_now()

    # ------------------------------------------------------------------
    # Settings dialog
    # ------------------------------------------------------------------
    def _open_settings(self):
        SettingsDialog(self.root, self.settings, self._apply_settings, show_translation_options=True)

    def _apply_settings(self, new_settings, initial=False):
        self.settings = new_settings
        set_animations_enabled(self.settings.get("animations_enabled", True))

        scale = self.settings.get("font_scale", 1.0)
        base_size = 14
        new_size = max(9, round(base_size * scale))
        try:
            self.input_text.configure(font=(FONT_FAMILY, new_size))
            self.output_text.configure(font=(FONT_FAMILY, new_size))
        except tk.TclError:
            pass

        if self.settings.get("high_contrast"):
            self.input_text.configure(highlightthickness=2, highlightbackground=COLOR_ACCENT)
        else:
            self.input_text.configure(highlightthickness=0)

        if not initial:
            target = self.settings.get("target_language", "en")
            if target != self.target_lang_var.get():
                self.target_lang_var.set(target)
                code_to_label = {code: label for label, code in settings_store.BRIDGE_LANGUAGES}
                self._bridge_display_var.set(code_to_label.get(target, "English"))
            self._last_translated_raw = None
            self._trigger_translate_now()

    # ------------------------------------------------------------------
    # Input handling / debounce / pulse animation
    # ------------------------------------------------------------------
    def _clear_input(self):
        self.input_text.delete("1.0", "end")
        self._set_output_plain("")
        self._clear_word_lists()
        self.status_label.config(text="")
        self._last_translated_raw = None

    def _on_input_key_release(self, _event=None):
        if self._debounce_job:
            self.root.after_cancel(self._debounce_job)
        self._start_pulse()
        self._debounce_job = self.root.after(REALTIME_DEBOUNCE_MS, self._do_translate)

    def _trigger_translate_now(self):
        if self._debounce_job:
            self.root.after_cancel(self._debounce_job)
            self._debounce_job = None
        self._do_translate()

    def _start_pulse(self):
        """Fading pulse effect on the 'computing' indicator while the
        debounce window is active, so typing doesn't feel like it's
        flashing the output violently -- it visibly signals 'still
        working' instead."""
        if self._pulse_job:
            self.root.after_cancel(self._pulse_job)

        def _pulse_step(i=0):
            half = PULSE_STEPS / 2
            t = (i % PULSE_STEPS)
            level = t / half if t <= half else (PULSE_STEPS - t) / half
            level = max(0.0, min(1.0, level))
            color = self._lerp(COLOR_OUTPUT_BG, COLOR_ACCENT_HOVER, level)
            try:
                self.pulse_label.config(fg=color)
            except tk.TclError:
                return
            self._pulse_job = self.root.after(PULSE_STEP_MS, lambda: _pulse_step(i + 1))

        _pulse_step(0)

    def _stop_pulse(self):
        if self._pulse_job:
            self.root.after_cancel(self._pulse_job)
            self._pulse_job = None
        self.pulse_label.config(fg=COLOR_OUTPUT_BG)

    @staticmethod
    def _lerp(c1, c2, t):
        c1 = c1.lstrip("#")
        c2 = c2.lstrip("#")
        r1, g1, b1 = int(c1[0:2], 16), int(c1[2:4], 16), int(c1[4:6], 16)
        r2, g2, b2 = int(c2[0:2], 16), int(c2[2:4], 16), int(c2[4:6], 16)
        r = int(r1 + (r2 - r1) * t)
        g = int(g1 + (g2 - g1) * t)
        b = int(b1 + (b2 - b1) * t)
        return f"#{r:02X}{g:02X}{b:02X}"

    def _set_output_plain(self, text):
        self.output_text.config(state="normal")
        self.output_text.delete("1.0", "end")
        self.output_text.insert("1.0", text)
        self.output_text.config(state="disabled")

    def _render_colored_output(self, text, direction):
        """Render `text` into the output box, colorizing tokens by part
        of speech (with a two-tone root/suffix split on the Normidian
        side) when Color Grammar is enabled; otherwise render as plain
        text."""
        self.output_text.config(state="normal")
        self.output_text.delete("1.0", "end")

        if not text:
            self.output_text.config(state="disabled")
            return

        if not self.color_mode_var.get():
            self.output_text.insert("1.0", text)
            self.output_text.config(state="disabled")
            return

        if direction == "en_to_no":
            tokens = colorize_normidian(text, self.engine)
        else:
            tokens = colorize_english(text, self.engine)

        for tok in tokens:
            if not tok.is_word or tok.root_len is None:
                self.output_text.insert("end", tok.text, (tok.pos,))
            else:
                root_part = tok.text[: tok.root_len]
                suffix_part = tok.text[tok.root_len:]
                self.output_text.insert("end", root_part, (tok.pos,))
                if suffix_part:
                    self.output_text.insert("end", suffix_part, ("suffix",))

        self.output_text.config(state="disabled")

    def _render_colored_input_preview(self):
        """Color-code the source text in place within the input box
        itself, using a transparent tag overlay, so both sides are
        colorized live while typing."""
        if not self.color_mode_var.get():
            for pos_key in POS_COLORS:
                self.input_text.tag_remove(pos_key, "1.0", "end")
            return

        text = self.input_text.get("1.0", "end-1c")
        direction = self.direction_var.get()

        for pos_key in POS_COLORS:
            self.input_text.tag_remove(pos_key, "1.0", "end")

        if direction == "en_to_no":
            tokens = colorize_english(text, self.engine)
        else:
            tokens = colorize_normidian(text, self.engine)

        idx = "1.0"
        for tok in tokens:
            start = idx
            end = f"{start}+{len(tok.text)}c"
            if tok.is_word:
                if tok.root_len is not None and tok.root_len < len(tok.text):
                    root_end = f"{start}+{tok.root_len}c"
                    self.input_text.tag_add(tok.pos, start, root_end)
                    self.input_text.tag_add("suffix", root_end, end)
                else:
                    self.input_text.tag_add(tok.pos, start, end)
            idx = end

    def _clear_word_lists(self):
        for child in self.processed_frame.winfo_children():
            child.destroy()
        for child in self.unknown_frame.winfo_children():
            child.destroy()
        self.negation_label.config(text="")

    def _do_translate(self):
        self._debounce_job = None
        self._stop_pulse()

        raw = self.input_text.get("1.0", "end").strip()
        self.status_label.config(text="")
        self._render_colored_input_preview()

        if not raw:
            self._set_output_plain("")
            self._clear_word_lists()
            self._set_gloss("")
            self._last_translated_raw = None
            return

        if raw == self._last_translated_raw:
            return

        direction = self.direction_var.get()
        if direction == "en_to_no":
            result = self.engine.translate_to_normidian(raw, self.word_order_var.get())
        else:
            result = self.engine.translate_to_english(raw)

        self._last_translated_raw = raw

        target = self.target_lang_var.get()
        if direction == "no_to_en" and target and target != "en" and result["output"]:
            self._set_gloss(f"English gloss: {result['output']}")
            self._render_colored_output(result["output"], direction)  # instant local preview
            self._bridge_request_id = getattr(self, "_bridge_request_id", 0) + 1
            self._start_pulse()
            self._run_bridge_async(result["output"], target, self._bridge_request_id)
        else:
            self._set_gloss("")
            self._render_colored_output(result["output"], direction)

        self._populate_word_lists(result, direction)

        if self.settings.get("auto_read_aloud") and result["output"]:
            self._read_aloud()

    def _set_gloss(self, text):
        if hasattr(self, "gloss_label"):
            self.gloss_label.config(text=text)

    def _run_bridge_async(self, english_text, target_lang, request_id):
        """Fetch the second (online) hop of the translation bridge on a
        background thread so typing never freezes on network latency,
        then hand the result back to the Tk main thread via `after()`."""
        import threading

        def _worker():
            try:
                translated = translate_service.bridge_translate(english_text, target_lang, "en")
                error = None
            except translate_service.TranslateServiceError as e:
                translated = None
                error = str(e)
            self.root.after(0, lambda: self._on_bridge_done(request_id, translated, error))

        threading.Thread(target=_worker, daemon=True).start()

    def _on_bridge_done(self, request_id, translated, error):
        if request_id != getattr(self, "_bridge_request_id", None):
            return  # a newer keystroke superseded this request
        self._stop_pulse()
        if error:
            self.status_label.config(text=f"⚠ {error} (showing English gloss instead)")
            return
        self._set_output_plain(translated)

    def _populate_word_lists(self, result, direction):
        for child in self.processed_frame.winfo_children():
            child.destroy()
        for child in self.unknown_frame.winfo_children():
            child.destroy()

        if result["processed"]:
            for eng, norm in result["processed"]:
                row = tk.Frame(self.processed_frame, bg=COLOR_PANEL)
                row.pack(fill="x", pady=1)
                tk.Label(
                    row, text=eng, bg=COLOR_PANEL, fg=COLOR_TEXT, font=(FONT_FAMILY, 9),
                    anchor="w", width=10,
                ).pack(side="left")
                tk.Label(
                    row, text="→", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 9),
                ).pack(side="left", padx=4)
                tk.Label(
                    row, text=norm, bg=COLOR_PANEL, fg=COLOR_OUTPUT_TEXT, font=(FONT_MONO, 9),
                    anchor="w",
                ).pack(side="left")
        else:
            tk.Label(
                self.processed_frame, text="—", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED,
                font=(FONT_FAMILY, 9),
            ).pack(anchor="w")

        if result["unknown"]:
            for word in result["unknown"]:
                tk.Label(
                    self.unknown_frame, text=f"• {word}", bg=COLOR_PANEL, fg=COLOR_DANGER,
                    font=(FONT_FAMILY, 9), anchor="w",
                ).pack(anchor="w", pady=1)

            first_unknown = result["unknown"][0]
            if direction == "en_to_no":
                suggestions = self.engine.suggest_english(first_unknown)
            else:
                suggestions = self.engine.suggest_normidian(first_unknown)
            if suggestions:
                self.status_label.config(
                    text=f'Unknown word: "{first_unknown}". Did you mean: {", ".join(suggestions)}?'
                )
            else:
                self.status_label.config(text=f'Unknown word: "{first_unknown}".')
        else:
            tk.Label(
                self.unknown_frame, text="—", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED,
                font=(FONT_FAMILY, 9),
            ).pack(anchor="w")

        if result["is_negated"]:
            self.negation_label.config(text="Negation detected — 'ne-' prefix applied to the verb.")
        else:
            self.negation_label.config(text="")

    # ------------------------------------------------------------------
    # Copy / TTS
    # ------------------------------------------------------------------
    def _copy_input(self):
        text = self.input_text.get("1.0", "end").strip()
        if not text:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()
        self.input_copied_label.pack(side="left", padx=(8, 0))
        self.root.after(1400, lambda: self.input_copied_label.pack_forget())

    def _swap_direction(self):
        """Swap direction AND swap the current output into the input box,
        so a translation can be immediately flipped and re-checked."""
        output_text = self.output_text.get("1.0", "end").strip()
        self.direction_var.set(
            "no_to_en" if self.direction_var.get() == "en_to_no" else "en_to_no"
        )
        self._on_direction_change(preserve_text=output_text)

    def _copy_output(self):
        text = self.output_text.get("1.0", "end").strip()
        if not text:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()
        self.copied_label.pack(side="left", padx=(10, 0))
        self.root.after(1400, lambda: self.copied_label.pack_forget())

    def _read_aloud(self):
        text = self.output_text.get("1.0", "end").strip()
        if not text:
            return
        if not PYTTSX3_AVAILABLE:
            messagebox.showinfo(
                "Text-to-Speech Unavailable",
                "The pyttsx3 library isn't installed.\n\nInstall it with:  pip install pyttsx3",
            )
            return
        try:
            if self.tts_engine is None:
                self.tts_engine = pyttsx3.init()
            self.tts_engine.setProperty("rate", int(self.settings.get("tts_rate", 175)))
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
        except Exception as e:
            messagebox.showerror("Text-to-Speech Error", f"Something went wrong:\n\n{e}")

    # ==================================================================
    # DICTIONARY TAB (read-only browser)
    # ==================================================================
    def _build_dictionary_tab(self):
        self.dict_search_var = tk.StringVar(value="")
        self.dict_filter_var = tk.StringVar(value="all")

        container = tk.Frame(self.dictionary_tab, bg=COLOR_PANEL)
        container.pack(fill="both", expand=True, pady=(14, 0))

        top_row = tk.Frame(container, bg=COLOR_PANEL)
        top_row.pack(fill="x", padx=18, pady=(18, 8))
        tk.Label(
            top_row, text="Dictionary Browser", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 14, "bold"),
        ).pack(side="left")
        self.dict_count_label = tk.Label(
            top_row, text="", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 9),
        )
        self.dict_count_label.pack(side="left", padx=(10, 0), pady=(4, 0))
        tk.Label(
            top_row, text="read-only -- use the Dictionary Manager app to edit",
            bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 8, "italic"),
        ).pack(side="right", pady=(4, 0))

        search_row = tk.Frame(container, bg=COLOR_PANEL)
        search_row.pack(fill="x", padx=18, pady=(0, 8))
        search_entry = FadeEntry(search_row, textvariable=self.dict_search_var)
        search_entry.pack(side="left", fill="x", expand=True, ipady=6)
        tk.Label(search_row, text="🔍", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED).pack(side="left", padx=(8, 0))
        self.dict_search_var.trace_add("write", lambda *a: self._refresh_dictionary_list())

        filter_row = tk.Frame(container, bg=COLOR_PANEL)
        filter_row.pack(fill="x", padx=18, pady=(0, 10))
        options = [("All", "all")] + [(POS_LABELS[c], c) for c in ALL_CATEGORIES]
        for label, value in options:
            tk.Radiobutton(
                filter_row, text=label, value=value, variable=self.dict_filter_var,
                bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_FIELD,
                activebackground=COLOR_PANEL, activeforeground=COLOR_TEXT,
                font=(FONT_FAMILY, 9), command=self._refresh_dictionary_list,
            ).pack(side="left", padx=(0, 8))

        list_scroll_frame = tk.Frame(container, bg=COLOR_PANEL)
        list_scroll_frame.pack(fill="both", expand=True, padx=18, pady=(0, 16))

        canvas = tk.Canvas(list_scroll_frame, bg=COLOR_PANEL, highlightthickness=0)
        scrollbar = ttk.Scrollbar(list_scroll_frame, orient="vertical", command=canvas.yview)
        self.dict_list_inner = tk.Frame(canvas, bg=COLOR_PANEL)

        self.dict_list_inner.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas_window = canvas.create_window((0, 0), window=self.dict_list_inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        def _resize_inner(event):
            canvas.itemconfig(canvas_window, width=event.width)

        canvas.bind("<Configure>", _resize_inner)

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self._refresh_dictionary_list()

    def _refresh_dictionary_list(self):
        if not hasattr(self, "dict_list_inner"):
            return
        for child in self.dict_list_inner.winfo_children():
            child.destroy()

        query = self.dict_search_var.get().strip().lower()
        chosen_filter = self.dict_filter_var.get()
        categories = ALL_CATEGORIES if chosen_filter == "all" else [chosen_filter]

        total_shown = 0
        total_all = sum(len(self.dictionary.get(c, {})) for c in ALL_CATEGORIES)

        for cat in categories:
            entries = self.dictionary.get(cat, {})
            matches = {
                k: v for k, v in entries.items()
                if not query or query in k.lower() or query in str(v.get("Root", "")).lower()
            }
            if not matches:
                continue

            tk.Label(
                self.dict_list_inner, text=POS_LABELS.get(cat, cat), bg=COLOR_PANEL,
                fg=POS_COLORS.get(cat, COLOR_TEXT), font=(FONT_FAMILY, 11, "bold"),
                anchor="w",
            ).pack(fill="x", pady=(12, 4))

            for eng_key in sorted(matches.keys()):
                entry = matches[eng_key]
                card = self._build_dict_view_card(self.dict_list_inner, cat, eng_key, entry)
                card.pack(fill="x", pady=2)
                total_shown += 1

        self.dict_count_label.config(text=f"{total_shown} shown / {total_all} total")

    def _build_dict_view_card(self, parent, category, english_key, entry):
        card = FadeCard(parent, height=40)

        eng_label = tk.Label(
            card, text=english_key, bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10), anchor="w", width=16,
        )
        eng_label.pack(side="left", padx=(10, 6))

        root_label = tk.Label(
            card, text=entry.get("Root", ""), bg=COLOR_PANEL, fg=POS_COLORS.get(category, COLOR_TEXT),
            font=(FONT_MONO, 10), anchor="w", width=14,
        )
        root_label.pack(side="left", padx=6)

        meaning_label = tk.Label(
            card, text=entry.get("Meaning", ""), bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED,
            font=(FONT_FAMILY, 9), anchor="w",
        )
        meaning_label.pack(side="left", padx=6, fill="x", expand=True)

        def _try_it(_e=None):
            """Clicking a word drops it straight into the translator as a
            quick way to see it conjugated/declined in context."""
            self.notebook.select(self.translator_tab)
            if self.direction_var.get() != "en_to_no":
                self.direction_var.set("en_to_no")
                self._on_direction_change()
            self.input_text.delete("1.0", "end")
            self.input_text.insert("1.0", f"the {english_key}")
            self._trigger_translate_now()

        for w in (card, eng_label, root_label, meaning_label):
            w.configure(cursor="hand2")
            w.bind("<Button-1>", _try_it)
            w.bind("<Enter>", lambda e: card.configure(bg="#33384A") or [
                x.configure(bg="#33384A") for x in (eng_label, root_label, meaning_label)
            ])
            w.bind("<Leave>", lambda e: card.configure(bg=COLOR_PANEL) or [
                x.configure(bg=COLOR_PANEL) for x in (eng_label, root_label, meaning_label)
            ])

        return card

    # ==================================================================
    # GRAMMAR GUIDE TAB
    # ==================================================================
    def _build_grammar_tab(self):
        container = tk.Frame(self.grammar_tab, bg=COLOR_PANEL)
        container.pack(fill="both", expand=True, pady=(14, 0))

        canvas = tk.Canvas(container, bg=COLOR_PANEL, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=COLOR_PANEL)

        scroll_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        def _resize_inner(event):
            canvas.itemconfig(canvas_window, width=event.width)

        canvas.bind("<Configure>", _resize_inner)

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        sections = [
            ("Overview", "Normidian is a highly inflected language: word order is "
             "completely flexible (SVO, OSV, VOS) because grammatical meaning is "
             "carried entirely by articles, vowel shifts, and suffixes rather than "
             "by position in the sentence. Because of this, the Normidian → English "
             "direction doesn't need a word-order setting -- the engine reconstructs "
             "subject, verb, and object from the case markers on each word."),
            ("Nouns & Gender", "Every noun is either LIVING (animate) or DEAD "
             "(inanimate). This gender determines which article and case suffix "
             "attaches to it.\n\n"
             "•  Subject (Nominative): bare root — for both genders\n"
             "•  Direct Object (Accusative): bare root for Living, root + '-þnes' for Dead\n"
             "•  Possessor (Genitive): root + '-þes' — both genders\n"
             "•  Recipient / Location (Dative): root + '-þe' — both genders\n"
             "•  Plural: root + '-þas' — both genders"),
            ("Articles", "Articles ('the') must agree with the noun's gender and case:\n\n"
             "•  Living Subject: ðse\n"
             "•  Dead Subject: ðsaþ\n"
             "•  Living Object: ðnes\n"
             "•  Dead Object: ðsaþ\n"
             "•  Possessor (either gender): ðœþ\n"
             "•  Recipient (either gender): þœn\n"
             "•  Plural (any subject/object): þasð"),
            ("Adjectives", "Adjectives agree with the noun they describe, but the "
             "pattern depends on whether an article is present.\n\n"
             "WEAK agreement (article present): every adjective simply takes the "
             "universal suffix '-ðn', regardless of gender or case — the article "
             "already carries that information.\n\n"
             "STRONG agreement (no article, e.g. 'a good king'): the adjective "
             "itself must show case and gender —\n"
             "•  Strong Living Subject: '-e'\n"
             "•  Strong Living Object: '-en'\n"
             "•  Strong Dead Object: '-re'\n"
             "•  Strong Possessor/Recipient: '-þu'"),
            ("Pronouns", "I = I   ·   You = ðu   ·   He = þses   ·   She = ƿhes\n"
             "It = þt   ·   We = Þæ   ·   They = ðhœy"),
            ("Verbs — Present Tense", "Verbs conjugate to match their subject:\n\n"
             "•  I: root + '-ies'\n"
             "•  You: root + '-ðus'\n"
             "•  He / She / It: root + '-ƿues'\n"
             "•  We / You-all / They: bare root"),
            ("Verbs — Past Tense", "Verbs split into two families for the past tense.\n\n"
             "WEAK verbs (regular): insert the past-tense marker '-ð-' between the "
             "root and the subject suffix.\n"
             "   Example: ƿlak (walk) → 'I walked' = ƿlak + ð + ies = ƿlakðies\n\n"
             "STRONG verbs (irregular): no '-ð-' marker. Instead, the internal "
             "vowel of the root mutates, then the normal subject suffix is added.\n"
             "   •  If the vowel is A, E, or I → it shifts to œ\n"
             "   •  If the vowel is O or U → it shifts to æ\n"
             "   Example: gið (give), vowel is i → 'I gave' = gœð + ies = gœðies"),
            ("Negation", "Negation is expressed with a 'ne-' prefix on the main verb, "
             "rather than a separate word. English 'does not walk' becomes ne-ƿlakƿues. "
             "The Translator detects English 'not' (and do/does/did + not) automatically "
             "and strips it in favor of the prefix; going the other direction, a leading "
             "'ne' token is recognized and rendered back out as 'does not …'."),
            ("Prepositions, Adverbs & Conjunctions", "Prepositions, adverbs, and "
             "conjunctions are all root-only dictionary entries (no case or tense "
             "inflection) drawn from Old English roots -- e.g. 'and' -> ond, "
             "'but' -> ac, 'if' -> gif, 'because' -> forðamþe. They pass straight "
             "through the translation in either direction and are shown in their "
             "own colors on the legend under the output box."),
            ("Word Order Freedom", "Because case is marked directly on each word, "
             "sentences can be freely reordered without losing meaning.\n\n"
             "Standard SVO:\n"
             "  ðse grōtðn cyniðg ġeseohƿues ðsaþ grōtðn ricƿþnes.\n"
             "Poetic OSV:\n"
             "  ðsaþ grōtðn ricƿþnes ðse grōtðn cyniðg ġeseohƿues.\n\n"
             "Both mean: 'The great king sees the great rock.' — the meaning survives "
             "the reordering because 'ricƿ' still carries its '-þnes' dead-object tag."),
            ("Color-Coded Grammar", "When Color Grammar is enabled on the Translator "
             "tab, every word is colored by its part of speech, and the SAME color "
             "is used on both sides of the translation so you can visually match "
             "words across languages. On the Normidian side, suffixes are shown in "
             "a distinct accent color separate from the root, since Normidian fuses "
             "grammatical information directly onto the word. See the legend under "
             "the output box for the full color key."),
        ]

        for heading, body in sections:
            self._add_grammar_section(scroll_frame, heading, body)

    def _add_grammar_section(self, parent, heading, body):
        section = tk.Frame(parent, bg=COLOR_PANEL)
        section.pack(fill="x", padx=24, pady=(18, 0))

        tk.Label(
            section, text=heading, bg=COLOR_PANEL, fg=COLOR_ACCENT_HOVER,
            font=(FONT_FAMILY, 13, "bold"), anchor="w",
        ).pack(fill="x")

        divider = tk.Frame(section, bg=COLOR_BORDER, height=1)
        divider.pack(fill="x", pady=(4, 8))

        tk.Label(
            section, text=body, bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10), anchor="w", justify="left", wraplength=900,
        ).pack(fill="x", pady=(0, 4))

    # ==================================================================
    # CHEAT SHEET TAB
    # ==================================================================
    def _build_cheatsheet_tab(self):
        container = tk.Frame(self.cheatsheet_tab, bg=COLOR_BG)
        container.pack(fill="both", expand=True, pady=(14, 0))

        canvas = tk.Canvas(container, bg=COLOR_BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=COLOR_BG)

        scroll_frame.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas_window = canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        def _resize_inner(event):
            canvas.itemconfig(canvas_window, width=event.width)

        canvas.bind("<Configure>", _resize_inner)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        grid = tk.Frame(scroll_frame, bg=COLOR_BG)
        grid.pack(fill="both", expand=True, padx=4, pady=4)
        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

        self._add_cheat_table(
            grid, 0, 0, "Noun Case Suffixes",
            ["Case", "Living", "Dead"],
            [
                ("Subject (Nom.)", "bare root", "bare root"),
                ("Object (Acc.)", "bare root", "-þnes"),
                ("Possessor (Gen.)", "-þes", "-þes"),
                ("Recipient (Dat.)", "-þe", "-þe"),
                ("Plural", "-þas", "-þas"),
            ],
        )

        self._add_cheat_table(
            grid, 0, 1, "Articles ('The')",
            ["Role", "Form"],
            [
                ("Living Subject", "ðse"),
                ("Dead Subject", "ðsaþ"),
                ("Living Object", "ðnes"),
                ("Dead Object", "ðsaþ"),
                ("Possessor", "ðœþ"),
                ("Recipient", "þœn"),
                ("Plural", "þasð"),
            ],
        )

        self._add_cheat_table(
            grid, 1, 0, "Adjective Agreement",
            ["Context", "Suffix"],
            [
                ("Weak (article present)", "-ðn (universal)"),
                ("Strong Living Subject", "-e"),
                ("Strong Living Object", "-en"),
                ("Strong Dead Object", "-re"),
                ("Strong Poss./Recip.", "-þu"),
            ],
        )

        self._add_cheat_table(
            grid, 1, 1, "Verb — Present Tense",
            ["Subject", "Suffix"],
            [
                ("I", "-ies"),
                ("You", "-ðus"),
                ("He / She / It", "-ƿues"),
                ("We / You-all / They", "bare root"),
            ],
        )

        self._add_cheat_table(
            grid, 2, 0, "Pronouns",
            ["English", "Normidian"],
            [
                ("I", "I"), ("You", "ðu"), ("He", "þses"), ("She", "ƿhes"),
                ("It", "þt"), ("We", "Þæ"), ("They", "ðhœy"),
            ],
        )

        self._add_cheat_table(
            grid, 2, 1, "Special Characters",
            ["Character", "Sounds like"],
            [
                ("ð (eth)", "th (voiced), as in 'this'"),
                ("þ (thorn)", "th (unvoiced), as in 'thin'"),
                ("ƿ (wynn)", "w"),
                ("œ (oe)", "vowel-shifted a/e/i (strong verbs)"),
                ("æ (ash)", "vowel-shifted o/u (strong verbs)"),
            ],
        )

        self._add_cheat_table(
            grid, 3, 0, "Common Conjunctions",
            ["English", "Normidian"],
            [
                ("and", "ond"), ("or", "oððe"), ("but", "ac"), ("if", "gif"),
                ("because", "forðamþe"), ("although", "þeah"), ("when", "þonne"),
                ("that", "þæt"), ("so", "sƿa"), ("until", "oðþæt"),
            ],
        )

    def _add_cheat_table(self, parent, row, col, title, headers, rows):
        panel = tk.Frame(parent, bg=COLOR_PANEL)
        panel.grid(row=row, column=col, sticky="nsew", padx=8, pady=8)

        tk.Label(
            panel, text=title, bg=COLOR_PANEL, fg=COLOR_ACCENT_HOVER,
            font=(FONT_FAMILY, 12, "bold"), anchor="w",
        ).pack(fill="x", padx=14, pady=(12, 6))

        table = tk.Frame(panel, bg=COLOR_PANEL)
        table.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        for c in range(len(headers)):
            table.columnconfigure(c, weight=1)

        for c, h in enumerate(headers):
            tk.Label(
                table, text=h, bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED,
                font=(FONT_FAMILY, 9, "bold"), anchor="w",
            ).grid(row=0, column=c, sticky="ew", pady=(0, 4), padx=(0, 8))

        divider = tk.Frame(table, bg=COLOR_BORDER, height=1)
        divider.grid(row=1, column=0, columnspan=len(headers), sticky="ew", pady=(0, 4))

        for r, row_vals in enumerate(rows, start=2):
            for c, val in enumerate(row_vals):
                fg = COLOR_OUTPUT_TEXT if c > 0 else COLOR_TEXT
                tk.Label(
                    table, text=val, bg=COLOR_PANEL, fg=fg,
                    font=(FONT_MONO if c > 0 else FONT_FAMILY, 10), anchor="w",
                ).grid(row=r, column=c, sticky="ew", pady=2, padx=(0, 8))

    # ------------------------------------------------------------------
    # GitHub sync (read-only: fetch only, no writes ever)
    # ------------------------------------------------------------------
    def _load_from_github(self, initial=False):
        if not config.is_configured():
            self.sync_status_label.config(text="Not configured -- set GITHUB_TOKEN and REPO_NAME.")
            return

        self.sync_status_label.config(text="Fetching dictionary…", fg=COLOR_TEXT_MUTED)
        self.root.update_idletasks()
        try:
            data, _sha = cloud_sync.fetch_dictionary()
            self.dictionary = data
            self.engine.set_dictionary(self.dictionary)
            self.sync_status_label.config(text="✓ Dictionary loaded", fg=COLOR_SUCCESS)
            self._last_translated_raw = None
            self._trigger_translate_now()
            self._refresh_dictionary_list()
        except cloud_sync.CloudSyncError as e:
            self.sync_status_label.config(text="⚠ Load failed", fg=COLOR_DANGER)
            messagebox.showerror("GitHub Fetch Failed", str(e))


def main():
    root = tk.Tk()
    app = TranslatorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
