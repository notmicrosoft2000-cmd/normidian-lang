"""
normidian_engine.py
=====================
Core translation logic against the new schema:

    nouns_living / nouns_dead / verbs / adjectives  -> {English: {Root, Meaning}}
    prepositions / adverbs                          -> {English: {Root}}

Unlike the previous version, this engine does NOT require the sentence to
match a strict Subject-Verb-Object template. It uses a tag-and-filter
approach:

    1. Clean contractions ("don't" -> "do not").
    2. Tag every word with a part of speech (or "unknown").
    3. Strip "do/does/did" auxiliaries adjacent to "not" and raise a
       negation flag instead.
    4. Pull out the subject noun, object noun, and main verb from the
       tagged stream (whichever nouns/verb it finds, in order of
       appearance) and apply case/article/agreement rules to them.
    5. Apply the negation prefix to the translated verb if flagged.
    6. Any word that isn't a recognized noun/verb/adjective/article/
       pronoun -- including prepositions, adverbs, and anything missing
       from the dictionary -- is NOT dropped and does NOT crash the
       engine. It is passed through into the output wrapped in [brackets]
       so a translation is always produced.

This module holds no cloud/network code -- it operates purely on an
in-memory dictionary dict handed to it by whichever app is using it.
"""

import difflib
import re

from grammar import (
    ARTICLES, WEAK_ADJ_SUFFIX, STRONG_ADJ, PRESENT_SUFFIX, PRONOUNS,
    VOWELS_GROUP_1, VOWELS_GROUP_2, NOUN_SUFFIXES, ADJ_STRONG_SUFFIXES,
    VERB_PRESENT_SUFFIXES, PAST_MARKER, NEGATION_PREFIX,
    CONTRACTIONS, DO_AUXILIARIES, IRREGULAR_PLURALS, IRREGULAR_VERB_PAST,
    ALL_WORD_CATEGORIES, CATEGORIES_ROOT_ONLY,
)

WORD_RE = re.compile(r"[^\W\d_]+")


class NormidianEngine:
    """
    Stateless-ish translation engine. Holds a reference to an in-memory
    dictionary dict (loaded elsewhere, e.g. by cloud_sync at app launch)
    and never touches the network or disk itself.
    """

    def __init__(self, dictionary):
        """
        dictionary: the parsed normidian_dictionary.json content, matching
        the schema described in the module docstring above.
        """
        self.dictionary = dictionary or {}
        for key in ALL_WORD_CATEGORIES:
            self.dictionary.setdefault(key, {})

    def set_dictionary(self, dictionary):
        """Swap in a freshly-fetched dictionary (e.g. after a cloud sync)."""
        self.dictionary = dictionary or {}
        for key in ALL_WORD_CATEGORIES:
            self.dictionary.setdefault(key, {})

    # ------------------------------------------------------------------
    # Dictionary access helpers (schema: {English: {Root, Meaning}})
    # ------------------------------------------------------------------
    def all_english_words(self):
        words = []
        for cat in ALL_WORD_CATEGORIES:
            words.extend(self.dictionary.get(cat, {}).keys())
        return words

    def word_exists(self, english_word):
        """Case-insensitive check across ALL categories -- used by the
        Dictionary Manager to block duplicate English entries."""
        w = english_word.strip().lower()
        for cat in ALL_WORD_CATEGORIES:
            if w in {k.lower() for k in self.dictionary.get(cat, {}).keys()}:
                return True
        return False

    def find_english_word(self, word):
        """
        Return (category, entry_dict) for an English word, checking every
        category, with a regular-English lemmatization fallback for
        plurals/tenses the dictionary only stores as an infinitive/singular.
        Returns None if nothing matches.
        """
        w = word.lower()
        for cat in ALL_WORD_CATEGORIES:
            d = self.dictionary.get(cat, {})
            for key, entry in d.items():
                if key.lower() == w:
                    return cat, entry

        if w in PRONOUNS:
            return "pronouns", {"Root": PRONOUNS[w], "Meaning": w}

        # Irregular forms
        if w in IRREGULAR_PLURALS:
            lemma = IRREGULAR_PLURALS[w]
            for cat in ("nouns_living", "nouns_dead"):
                d = self.dictionary.get(cat, {})
                for key, entry in d.items():
                    if key.lower() == lemma:
                        return cat, entry
        if w in IRREGULAR_VERB_PAST:
            lemma = IRREGULAR_VERB_PAST[w]
            d = self.dictionary.get("verbs", {})
            for key, entry in d.items():
                if key.lower() == lemma:
                    return "verbs", entry

        # Regular lemmatization fallback (plurals, -ed, -s, -ies)
        lemma_candidates = []
        if w.endswith("ies") and len(w) > 3:
            lemma_candidates.append(w[:-3] + "y")
        if w.endswith("es") and len(w) > 2:
            lemma_candidates.append(w[:-2])
        if w.endswith("ed") and len(w) > 2:
            lemma_candidates.append(w[:-2])
            lemma_candidates.append(w[:-1])
        if w.endswith("s") and len(w) > 1:
            lemma_candidates.append(w[:-1])

        for cand in lemma_candidates:
            d = self.dictionary.get("verbs", {})
            for key, entry in d.items():
                if key.lower() == cand:
                    return "verbs", entry
        for cand in lemma_candidates:
            for cat in ("nouns_living", "nouns_dead"):
                d = self.dictionary.get(cat, {})
                for key, entry in d.items():
                    if key.lower() == cand:
                        return cat, entry
        return None

    @staticmethod
    def is_probable_proper_noun(word):
        """
        Heuristic: a capitalized, alphabetic word with no dictionary entry
        is treated as a proper noun (a name) and passed through
        untranslated in both directions, rather than being flagged as an
        unknown word. Names aren't part of Normidian's core vocabulary,
        so there's nothing to look up -- they carry over as-is, the same
        way they would between any two real languages.

        Caveat: this can't distinguish a genuine name from an ordinary
        word that's simply capitalized because it opens the sentence
        (e.g. a typo'd or missing dictionary entry for a common word).
        When in doubt, it's usually right to treat the miss as a name,
        since dictionary gaps in *mid*-sentence would still be capitalized
        too and this keeps translation from stalling on names.
        """
        return bool(word) and word.isalpha() and word[0].isupper()

    def all_normidian_roots(self):
        """Every Normidian surface root known to the dictionary, plus the
        fixed pronoun forms -- used for reverse lookup and fuzzy 'did you
        mean' suggestions on the Normidian side."""
        roots = []
        for cat in ALL_WORD_CATEGORIES:
            for entry in self.dictionary.get(cat, {}).values():
                root = entry.get("Root", "")
                if root:
                    roots.append(root)
        roots.extend(PRONOUNS.values())
        return roots

    def find_normidian_root(self, word):
        """
        Reverse-match a Normidian surface form back to a dictionary entry,
        by stripping known case/agreement/tense suffixes (see grammar.py).

        Returns a dict {"category", "english", "root", "gender", "case"}
        (gender/case are only meaningful for nouns) or None if nothing
        in the dictionary can explain the surface form.
        """
        w = word.lower()

        for eng, norm in PRONOUNS.items():
            if norm.lower() == w:
                return {"category": "pronouns", "english": eng, "root": norm,
                        "gender": None, "case": None}

        # Nouns: bare root (subject) or one of the case suffixes stripped.
        noun_candidates = [(w, "subject")]
        if w.endswith("þnes"):
            noun_candidates.append((w[:-4], "object"))
        if w.endswith("þes"):
            noun_candidates.append((w[:-3], "possessor"))
        if w.endswith("þas"):
            noun_candidates.append((w[:-3], "plural"))
        if w.endswith("þe"):
            noun_candidates.append((w[:-2], "recipient"))

        for cat in ("nouns_living", "nouns_dead"):
            gender = "living" if cat == "nouns_living" else "dead"
            for eng, entry in self.dictionary.get(cat, {}).items():
                root_l = entry.get("Root", "").lower()
                if not root_l:
                    continue
                for cand, case in noun_candidates:
                    if cand == root_l:
                        return {"category": cat, "english": eng, "root": entry["Root"],
                                "gender": gender, "case": case}

        # Adjectives: weak universal suffix, or one of the strong forms.
        adj_candidates = [w]
        for suf in [WEAK_ADJ_SUFFIX] + ADJ_STRONG_SUFFIXES:
            if w.endswith(suf) and len(w) > len(suf):
                adj_candidates.append(w[: -len(suf)])
        for eng, entry in self.dictionary.get("adjectives", {}).items():
            root_l = entry.get("Root", "").lower()
            if root_l and root_l in adj_candidates:
                return {"category": "adjectives", "english": eng, "root": entry["Root"],
                        "gender": None, "case": None}

        # Verbs: present-tense suffix, weak past ('-ð-' + suffix), or
        # strong past (vowel-shifted root + suffix).
        verb_candidates = [w]
        for suf in VERB_PRESENT_SUFFIXES:
            if w.endswith(suf):
                verb_candidates.append(w[: -len(suf)])
        for eng, entry in self.dictionary.get("verbs", {}).items():
            root = entry.get("Root", "")
            if not root:
                continue
            root_l = root.lower()
            vtype = self._infer_verb_type(root)
            if root_l in verb_candidates or w == root_l:
                return {"category": "verbs", "english": eng, "root": root,
                        "gender": None, "case": None}
            if vtype == "weak":
                for suf in VERB_PRESENT_SUFFIXES + [""]:
                    if w == (root_l + PAST_MARKER + suf):
                        return {"category": "verbs", "english": eng, "root": root,
                                "gender": None, "case": None}
            else:
                shifted = self._shift_vowels(root_l)
                for suf in VERB_PRESENT_SUFFIXES + [""]:
                    if w == (shifted + suf):
                        return {"category": "verbs", "english": eng, "root": root,
                                "gender": None, "case": None}

        # Prepositions / adverbs: root-only categories, exact match.
        for cat in CATEGORIES_ROOT_ONLY:
            for eng, entry in self.dictionary.get(cat, {}).items():
                if entry.get("Root", "").lower() == w:
                    return {"category": cat, "english": eng, "root": entry["Root"],
                            "gender": None, "case": None}

        return None

    # ------------------------------------------------------------------
    # Fuzzy "did you mean" suggestions
    # ------------------------------------------------------------------
    def suggest_english(self, word, n=5, cutoff=0.55):
        return difflib.get_close_matches(
            word.lower(), [w.lower() for w in self.all_english_words()], n=n, cutoff=cutoff
        )

    def suggest_normidian(self, word, n=5, cutoff=0.45):
        return difflib.get_close_matches(
            word.lower(), [w.lower() for w in self.all_normidian_roots()], n=n, cutoff=cutoff
        )

    # ------------------------------------------------------------------
    # Grammar mechanics (unchanged rules -- see grammar.py)
    # ------------------------------------------------------------------
    @staticmethod
    def _shift_vowels(root):
        """Apply strong-verb vowel mutation: first A/E/I -> œ, first O/U -> æ."""
        result_chars = []
        shifted_once = False
        for ch in root:
            lower_ch = ch.lower()
            if not shifted_once and lower_ch in VOWELS_GROUP_1:
                result_chars.append("œ")
                shifted_once = True
            elif not shifted_once and lower_ch in VOWELS_GROUP_2:
                result_chars.append("æ")
                shifted_once = True
            else:
                result_chars.append(ch)
        return "".join(result_chars)

    def get_article(self, gender, case):
        if case in ("possessor", "recipient", "plural"):
            return ARTICLES[("any", case)]
        return ARTICLES.get((gender, case))

    def get_noun_case_form(self, root, gender, case):
        if case == "subject":
            return root
        if case == "object":
            return root if gender == "living" else root + "þnes"
        if case == "possessor":
            return root + "þes"
        if case == "recipient":
            return root + "þe"
        if case == "plural":
            return root + "þas"
        return root

    def get_adjective_form(self, root, has_article, gender=None, case=None):
        if has_article:
            return root + WEAK_ADJ_SUFFIX
        if gender == "living" and case == "subject":
            return root + STRONG_ADJ["living_subject"]
        if gender == "living" and case == "object":
            return root + STRONG_ADJ["living_object"]
        if gender == "dead" and case == "object":
            return root + STRONG_ADJ["dead_object"]
        if case in ("possessor", "recipient"):
            return root + STRONG_ADJ["possessor_recipient"]
        return root

    def conjugate_verb_root(self, verb_root, verb_type, subject_person="he_she_it", tense="present"):
        """
        verb_type: "weak" or "strong" (we infer weak by default since the
        new schema doesn't store a type flag -- see _infer_verb_type).
        """
        suffix = PRESENT_SUFFIX.get(subject_person, PRESENT_SUFFIX["he_she_it"])
        if tense == "present":
            return verb_root + suffix
        if verb_type == "weak":
            return verb_root + PAST_MARKER + suffix
        return self._shift_vowels(verb_root) + suffix

    @staticmethod
    def _infer_verb_type(verb_root):
        """
        The new schema's verbs category only stores {Root, Meaning} -- no
        explicit weak/strong flag. We default every verb to weak
        conjugation (regular '-ð-' past marker) since that's the
        productive/regular pattern in Normidian; a small hard-coded set of
        known strong verbs from the original vocabulary is preserved for
        backward compatibility with existing dictionary entries.
        """
        known_strong_roots = {"ġeseoh", "gið"}
        return "strong" if verb_root in known_strong_roots else "weak"

    # ------------------------------------------------------------------
    # Contraction cleansing + negation flagging (Part 4.1 / 4.2)
    # ------------------------------------------------------------------
    def _expand_contractions(self, text):
        result = text
        for contraction, expansion in CONTRACTIONS.items():
            result = re.sub(re.escape(contraction), expansion, result, flags=re.IGNORECASE)
        return result

    def _strip_negation_auxiliaries(self, tokens_lower):
        """
        Scan for a DO_AUXILIARY immediately followed by "not", strip both
        out of the token stream, and return (cleaned_tokens, is_negated).
        Also handles a bare "not" without an auxiliary by stripping "not"
        alone and still flagging negation.
        """
        is_negated = False
        cleaned = []
        i = 0
        n = len(tokens_lower)
        while i < n:
            tok = tokens_lower[i]
            nxt = tokens_lower[i + 1] if i + 1 < n else None
            if tok in DO_AUXILIARIES and nxt == "not":
                is_negated = True
                i += 2  # skip both "does" and "not"
                continue
            if tok == "not":
                is_negated = True
                i += 1
                continue
            cleaned.append(tok)
            i += 1
        return cleaned, is_negated

    def _align_original_tokens(self, raw_tokens, lower_tokens):
        """
        Re-apply the exact same skip logic as _strip_negation_auxiliaries,
        but on the ORIGINAL-CASED tokens, so bracketed fallback text in the
        output preserves the user's original capitalization.
        """
        aligned = []
        i = 0
        n = len(lower_tokens)
        while i < n:
            low = lower_tokens[i]
            nxt_low = lower_tokens[i + 1] if i + 1 < n else None
            if low in DO_AUXILIARIES and nxt_low == "not":
                i += 2
                continue
            if low == "not":
                i += 1
                continue
            aligned.append(raw_tokens[i])
            i += 1
        return aligned

    # ------------------------------------------------------------------
    # Tag-and-filter core extraction (Part 4.3)
    # ------------------------------------------------------------------
    def _tag_tokens(self, tokens_lower):
        """
        Classify each lowercase token. Returns a list of
        (category_or_None, entry_or_None) tuples, aligned 1:1 with
        tokens_lower.
        """
        tagged = []
        for tok in tokens_lower:
            if tok in ("the", "a", "an"):
                tagged.append(("article", None))
                continue
            found = self.find_english_word(tok)
            if found:
                cat, entry = found
                tagged.append((cat, entry))
            else:
                tagged.append((None, None))
        return tagged

    def translate_to_normidian(self, text, word_order="SVO"):
        """
        Translate English -> Normidian using tag-and-filter extraction.

        Returns a dict with:
            "output": the translated string (always produced -- never None)
            "processed": list of (english_word, normidian_form) that were
                         successfully translated
            "unknown": list of original-cased words that had no dictionary
                       entry and were passed through in [brackets]
            "is_negated": whether negation was detected
        """
        stripped = text.strip()
        trailing_punct = ""
        m = re.search(r"[.!?]+$", stripped)
        if m:
            trailing_punct = m.group(0)
            stripped = stripped[: m.start()]

        cleansed = self._expand_contractions(stripped)

        raw_tokens = WORD_RE.findall(cleansed)
        if not raw_tokens:
            return {"output": "", "processed": [], "unknown": [], "is_negated": False}

        lower_tokens = [t.lower() for t in raw_tokens]

        lower_tokens_clean, is_negated = self._strip_negation_auxiliaries(lower_tokens)
        aligned_original = self._align_original_tokens(raw_tokens, lower_tokens)

        tagged = self._tag_tokens(lower_tokens_clean)

        subject_noun = None
        object_noun = None
        verb_entry = None
        adjectives_before_subject = []
        adjectives_before_object = []
        seen_noun_count = 0

        unknown_words = []
        processed_pairs = []
        fallback_extras = []

        for idx, (cat, entry) in enumerate(tagged):
            original_word = aligned_original[idx] if idx < len(aligned_original) else lower_tokens_clean[idx]

            if cat == "verbs" and verb_entry is None:
                root = entry["Root"]
                vtype = self._infer_verb_type(root)
                verb_entry = (root, vtype, original_word)
                continue

            if cat in ("nouns_living", "nouns_dead"):
                if seen_noun_count == 0:
                    subject_noun = (cat, entry, original_word)
                else:
                    object_noun = (cat, entry, original_word)
                seen_noun_count += 1
                continue

            if cat == "adjectives":
                if seen_noun_count == 0:
                    adjectives_before_subject.append((entry, original_word))
                else:
                    adjectives_before_object.append((entry, original_word))
                continue

            if cat in CATEGORIES_ROOT_ONLY:
                fallback_extras.append((idx, f"[{original_word}]"))
                continue

            if cat == "article":
                continue

            if cat == "pronouns":
                fallback_extras.append((idx, f"[{original_word}]"))
                continue

            if self.is_probable_proper_noun(original_word):
                fallback_extras.append((idx, original_word))
                processed_pairs.append((original_word, original_word))
                continue

            unknown_words.append(original_word)
            fallback_extras.append((idx, f"[{original_word}]"))

        pieces = {"S": None, "V": None, "O": None}

        if subject_noun:
            cat, entry, orig = subject_noun
            gender = "living" if cat == "nouns_living" else "dead"
            root = entry["Root"]
            article = self.get_article(gender, "subject")
            noun_form = self.get_noun_case_form(root, gender, "subject")
            adj_forms = [
                self.get_adjective_form(a_entry["Root"], True)
                for a_entry, _ in adjectives_before_subject
            ]
            pieces["S"] = " ".join([article] + adj_forms + [noun_form])
            processed_pairs.append((orig, noun_form))
            for a_entry, a_orig in adjectives_before_subject:
                processed_pairs.append((a_orig, self.get_adjective_form(a_entry["Root"], True)))

        if verb_entry:
            root, vtype, orig = verb_entry
            verb_form = self.conjugate_verb_root(root, vtype, "he_she_it", "present")
            if is_negated:
                verb_form = NEGATION_PREFIX + verb_form
            pieces["V"] = verb_form
            processed_pairs.append((orig, verb_form))

        if object_noun:
            cat, entry, orig = object_noun
            gender = "living" if cat == "nouns_living" else "dead"
            root = entry["Root"]
            article = self.get_article(gender, "object")
            noun_form = self.get_noun_case_form(root, gender, "object")
            adj_forms = [
                self.get_adjective_form(a_entry["Root"], True)
                for a_entry, _ in adjectives_before_object
            ]
            pieces["O"] = " ".join([article] + adj_forms + [noun_form])
            processed_pairs.append((orig, noun_form))
            for a_entry, a_orig in adjectives_before_object:
                processed_pairs.append((a_orig, self.get_adjective_form(a_entry["Root"], True)))

        order_map = {
            "SVO": ["S", "V", "O"],
            "OSV": ["O", "S", "V"],
            "VOS": ["V", "O", "S"],
        }
        order = order_map.get(word_order, ["S", "V", "O"])
        core_parts = [pieces[p] for p in order if pieces.get(p)]

        extra_parts = [t for _, t in sorted(fallback_extras, key=lambda x: x[0])]

        all_parts = core_parts + extra_parts
        result = " ".join(p for p in all_parts if p)

        if result:
            result = result[0].upper() + result[1:]
            result = result + trailing_punct

        return {
            "output": result,
            "processed": processed_pairs,
            "unknown": unknown_words,
            "is_negated": is_negated,
        }

    def translate_to_english(self, text):
        """
        Translate Normidian -> English via reverse dictionary lookup
        (find_normidian_root) plus a simple gloss reconstruction.

        Because Normidian marks grammatical role directly on each word
        (case suffixes, articles) rather than through position, this
        works regardless of the source word order -- there's no
        equivalent of the `word_order` parameter needed here.

        Returns the same {"output", "processed", "unknown", "is_negated"}
        shape as translate_to_normidian(), so the UI can treat both
        directions identically.
        """
        stripped = text.strip()
        trailing_punct = ""
        m = re.search(r"[.!?]+$", stripped)
        if m:
            trailing_punct = m.group(0)
            stripped = stripped[: m.start()]

        raw_tokens = WORD_RE.findall(stripped)
        if not raw_tokens:
            return {"output": "", "processed": [], "unknown": [], "is_negated": False}

        article_forms = {a.lower() for a in ARTICLES.values()}
        neg_trigger = NEGATION_PREFIX.split("-")[0]  # "ne" (the hyphen never
        # survives tokenization, so "ne-verb" arrives as two tokens: "ne", "verb")

        is_negated = False
        unknown_words = []
        processed_pairs = []
        extras = []

        subject_eng = None
        object_eng = None
        subject_is_name = False
        object_is_name = False
        subj_adjs = []
        obj_adjs = []
        pending_adjs = []
        verb_eng = None
        pronoun_eng = None
        seen_noun = False

        i = 0
        n = len(raw_tokens)
        while i < n:
            tok = raw_tokens[i]
            low = tok.lower()

            if low == neg_trigger and i + 1 < n:
                nxt = raw_tokens[i + 1]
                match = self.find_normidian_root(nxt)
                if match and match["category"] == "verbs":
                    is_negated = True
                    verb_eng = match["english"]
                    processed_pairs.append((f"{tok} {nxt}", match["english"]))
                    i += 2
                    continue

            if low in article_forms:
                i += 1
                continue

            match = self.find_normidian_root(tok)
            if not match:
                if self.is_probable_proper_noun(tok):
                    # Treat as a name: place it like a noun (subject first,
                    # then object) but without an English "the" in front.
                    if seen_noun:
                        object_eng = tok
                        object_is_name = True
                        obj_adjs.extend(pending_adjs)
                    else:
                        subject_eng = tok
                        subject_is_name = True
                        subj_adjs.extend(pending_adjs)
                    seen_noun = True
                    pending_adjs = []
                    processed_pairs.append((tok, tok))
                    i += 1
                    continue
                unknown_words.append(tok)
                i += 1
                continue

            cat = match["category"]
            eng_key = match["english"]

            if cat == "verbs":
                verb_eng = eng_key
                processed_pairs.append((tok, eng_key))
            elif cat in ("nouns_living", "nouns_dead"):
                is_object_form = match["case"] in ("object", "recipient", "possessor", "plural") or seen_noun
                if is_object_form:
                    object_eng = eng_key
                    obj_adjs.extend(pending_adjs)
                else:
                    subject_eng = eng_key
                    subj_adjs.extend(pending_adjs)
                seen_noun = True
                pending_adjs = []
                processed_pairs.append((tok, eng_key))
            elif cat == "adjectives":
                pending_adjs.append(eng_key)
                processed_pairs.append((tok, eng_key))
            elif cat == "pronouns":
                pronoun_eng = eng_key
                processed_pairs.append((tok, eng_key))
            else:  # prepositions / adverbs -- glossed in place, appended at the end
                extras.append(eng_key)
                processed_pairs.append((tok, eng_key))

            i += 1

        if pending_adjs:
            if object_eng is not None:
                obj_adjs.extend(pending_adjs)
            elif subject_eng is not None:
                subj_adjs.extend(pending_adjs)

        result_words = []
        if subject_eng:
            if not subject_is_name:
                result_words.append("the")
            result_words.extend(subj_adjs)
            result_words.append(subject_eng)
        elif pronoun_eng:
            result_words.append(pronoun_eng)

        if verb_eng:
            third_person = bool(subject_eng) or (pronoun_eng in ("he", "she", "it"))
            if is_negated:
                verb_out = f"does not {verb_eng}"
            elif third_person:
                verb_out = verb_eng + "s"
            else:
                verb_out = verb_eng
            result_words.append(verb_out)

        if object_eng:
            if not object_is_name:
                result_words.append("the")
            result_words.extend(obj_adjs)
            result_words.append(object_eng)

        result_words.extend(extras)

        if not result_words:
            result_words = subj_adjs + obj_adjs

        result = " ".join(result_words)
        if result:
            result = result[0].upper() + result[1:] + trailing_punct

        return {
            "output": result,
            "processed": processed_pairs,
            "unknown": unknown_words,
            "is_negated": is_negated,
        }
