"""
colorizer.py
=============
Classifies each token in a sentence (English or Normidian) by part of
speech so the GUI can color-code them consistently. For Normidian
tokens, also splits the token into (root_span, suffix_span) so the root
can be colored by part-of-speech and the trailing case/tense/agreement
suffix highlighted separately -- this lets a user see at a glance which
grammatical tag is fused onto a word.

No GUI/Tkinter code lives here; this module returns plain data
structures that translator_app.py renders into a Text widget's tags.
"""

import re

from grammar import (
    ARTICLES, NOUN_SUFFIXES, WEAK_ADJ_SUFFIX, ADJ_STRONG_SUFFIXES,
    VERB_PRESENT_SUFFIXES, PAST_MARKER, CATEGORIES_WITH_MEANING, CATEGORIES_ROOT_ONLY,
)

TOKEN_RE = re.compile(r"[^\W\d_]+|[.,!?;:]+|\s+")


class ColorToken:
    """
    One rendered token. `text` is the original surface text (casing
    preserved). `pos` is a part-of-speech key into theme.POS_COLORS.
    `root_len` is how many leading characters of `text` belong to the
    root; the remainder is rendered in the distinct "suffix" color. If
    root_len is None, the whole token is colored uniformly by `pos`.
    """
    __slots__ = ("text", "pos", "root_len", "is_word")

    def __init__(self, text, pos="unknown", root_len=None, is_word=True):
        self.text = text
        self.pos = pos
        self.root_len = root_len
        self.is_word = is_word


def _split_ws_tokens(text):
    """Tokenize preserving whitespace/punctuation as separate non-word tokens."""
    return TOKEN_RE.findall(text)


def _strip_known_suffix(word_lower, suffix_list):
    """Return (root_length, suffix) if word ends with one of the given
    suffixes and has a non-empty root remaining; else (None, None).
    Longest suffixes are tried first (e.g. 'þnes' before 'þe')."""
    for suf in sorted(suffix_list, key=len, reverse=True):
        if word_lower.endswith(suf) and len(word_lower) > len(suf):
            return len(word_lower) - len(suf), suf
    return None, None


def colorize_english(text, engine):
    """Classify each token of an English sentence for display. English
    morphology is mostly analytic (no fused suffixes to split out), so
    root_len is always left as None."""
    raw_tokens = _split_ws_tokens(text)
    result = []
    for tok in raw_tokens:
        if tok.strip() == "" or not re.match(r"[^\W\d_]+", tok):
            result.append(ColorToken(tok, pos="unknown", is_word=False))
            continue

        low = tok.lower()
        if low in ("the", "a", "an"):
            result.append(ColorToken(tok, pos="article"))
            continue

        found = engine.find_english_word(low)
        if not found:
            if engine.is_probable_proper_noun(tok):
                result.append(ColorToken(tok, pos="proper_noun"))
            else:
                result.append(ColorToken(tok, pos="unknown"))
            continue

        cat, _entry = found
        if cat == "pronouns":
            result.append(ColorToken(tok, pos="pronouns"))
        elif cat in CATEGORIES_WITH_MEANING or cat in CATEGORIES_ROOT_ONLY:
            result.append(ColorToken(tok, pos=cat))
        else:
            result.append(ColorToken(tok, pos="unknown"))
    return result


def colorize_normidian(text, engine):
    """Classify each token of a Normidian sentence for display, splitting
    matched words into a root/suffix boundary so the caller can render
    the root in its part-of-speech color and the trailing suffix in the
    distinct suffix accent color."""
    raw_tokens = _split_ws_tokens(text)
    result = []
    article_forms = {a.lower() for a in ARTICLES.values()}

    for tok in raw_tokens:
        if tok.strip() == "" or not re.match(r"[^\W\d_]+", tok):
            result.append(ColorToken(tok, pos="unknown", is_word=False))
            continue

        low = tok.lower()

        if low in article_forms:
            result.append(ColorToken(tok, pos="article"))
            continue

        match = engine.find_normidian_root(tok)
        if not match:
            if engine.is_probable_proper_noun(tok):
                result.append(ColorToken(tok, pos="proper_noun"))
            else:
                result.append(ColorToken(tok, pos="unknown"))
            continue

        cat = match["category"]
        norm_root = match["root"]

        if cat == "pronouns":
            result.append(ColorToken(tok, pos="pronouns"))
            continue

        if cat in ("nouns_living", "nouns_dead"):
            rlen, _suf = _strip_known_suffix(low, NOUN_SUFFIXES)
            root_len = rlen if rlen is not None else (
                len(norm_root) if len(norm_root) <= len(tok) else None
            )
            result.append(ColorToken(tok, pos=cat, root_len=root_len))
            continue

        if cat == "adjectives":
            rlen, _suf = _strip_known_suffix(low, [WEAK_ADJ_SUFFIX] + ADJ_STRONG_SUFFIXES)
            root_len = rlen if rlen is not None else len(norm_root)
            result.append(ColorToken(tok, pos="adjectives", root_len=root_len))
            continue

        if cat == "verbs":
            # Try present-tense suffixes, then weak past ('-ð-' + suffix).
            # Strong verbs vowel-shift the root itself, so if neither
            # matches, just fall back to the dictionary root's length.
            rlen, _suf = _strip_known_suffix(low, VERB_PRESENT_SUFFIXES)
            if rlen is None:
                for vsuf in VERB_PRESENT_SUFFIXES + [""]:
                    marker_form = PAST_MARKER + vsuf
                    if low.endswith(marker_form) and len(low) > len(marker_form):
                        rlen = len(low) - len(marker_form)
                        break
            if rlen is None:
                rlen = len(norm_root) if len(norm_root) <= len(tok) else None
            result.append(ColorToken(tok, pos="verbs", root_len=rlen))
            continue

        # prepositions / adverbs -- root-only categories, no suffixes
        result.append(ColorToken(tok, pos=cat))

    return result
