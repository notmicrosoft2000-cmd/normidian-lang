"""
cloud_sync.py
==============
Handles downloading and uploading normidian_dictionary.json directly to a
GitHub repository via the GitHub REST API (contents endpoint). No local
file is treated as the permanent source of truth -- GitHub is.

This module requires three configuration values, which you set as
environment variables (see the setup guide at the top of the chat
response, or the docstring in config.py):

    GITHUB_TOKEN   - a GitHub Personal Access Token with 'repo' scope
    REPO_NAME      - "username/repository", e.g. "jdoe/normidian-lang"
    BRANCH         - the branch to read/write, e.g. "main"

The remote file path is fixed to "normidian_dictionary.json" at the repo
root, per the schema requirements.
"""

import base64
import json

import requests

import config

REMOTE_FILE_PATH = "normidian_dictionary.json"
API_BASE = "https://api.github.com"


class CloudSyncError(Exception):
    """Raised when a GitHub API call fails or returns something unexpected."""
    pass


def _contents_url():
    # Read config.REPO_NAME live (not copied at import time) so changes to
    # the environment/config module between calls are always respected.
    return f"{API_BASE}/repos/{config.REPO_NAME}/contents/{REMOTE_FILE_PATH}"


def _headers():
    if not config.GITHUB_TOKEN:
        raise CloudSyncError(
            "GITHUB_TOKEN is not set. See config.py / the setup guide for how "
            "to configure your GitHub Personal Access Token."
        )
    return {
        "Authorization": f"token {config.GITHUB_TOKEN}",
        "Accept": "application/vnd.github+json",
    }


def fetch_dictionary():
    """
    Read Method.
    Sends a GET request to the GitHub contents API, decodes the Base64
    file content, and parses it into a Python dict.

    Returns:
        (dictionary: dict, sha: str)
        `sha` is the current blob hash on GitHub -- required later when
        writing an update, so GitHub can confirm we're not overwriting
        someone else's concurrent change.

    Raises:
        CloudSyncError on any network, auth, or parsing failure.
    """
    url = _contents_url()
    params = {"ref": config.BRANCH}

    try:
        response = requests.get(url, headers=_headers(), params=params, timeout=15)
    except requests.exceptions.RequestException as e:
        raise CloudSyncError(f"Network error while contacting GitHub: {e}") from e

    if response.status_code == 404:
        raise CloudSyncError(
            f"'{REMOTE_FILE_PATH}' was not found in {config.REPO_NAME} on branch "
            f"'{config.BRANCH}'. Make sure the file exists at the repository root."
        )
    if response.status_code == 401:
        raise CloudSyncError(
            "GitHub rejected the request (401 Unauthorized). Check that "
            "GITHUB_TOKEN is valid and has 'repo' scope."
        )
    if response.status_code != 200:
        raise CloudSyncError(
            f"GitHub returned an unexpected status {response.status_code}: "
            f"{response.text[:300]}"
        )

    payload = response.json()

    encoded_content = payload.get("content", "")
    sha = payload.get("sha")
    if not encoded_content or not sha:
        raise CloudSyncError("GitHub response was missing 'content' or 'sha'.")

    try:
        # GitHub returns content in Base64, split into newline chunks.
        decoded_bytes = base64.b64decode(encoded_content)
        text = decoded_bytes.decode("utf-8")
        data = json.loads(text)
    except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as e:
        raise CloudSyncError(f"Failed to decode/parse the dictionary JSON: {e}") from e

    return data, sha


def push_dictionary(dictionary, sha, commit_message="Update Normidian dictionary"):
    """
    Write Method.
    Encodes the given dictionary as Base64 JSON and PUTs it back to
    GitHub, using the provided `sha` (the hash of the version we last
    read) so GitHub can detect and reject conflicting concurrent edits.

    Args:
        dictionary: the full Python dict to persist.
        sha: the blob sha obtained from the most recent fetch_dictionary()
             call. Passing a stale sha will cause GitHub to return 409/422,
             which is surfaced as a CloudSyncError so the caller can
             re-fetch and retry rather than silently clobbering changes.
        commit_message: message shown in the repo's commit history.

    Returns:
        The new sha of the file after the update (str), so the caller can
        keep it for the next write without another round-trip fetch.

    Raises:
        CloudSyncError on any network, auth, conflict, or encoding failure.
    """
    url = _contents_url()

    try:
        json_text = json.dumps(dictionary, ensure_ascii=False, indent=2)
        encoded_content = base64.b64encode(json_text.encode("utf-8")).decode("ascii")
    except (TypeError, ValueError) as e:
        raise CloudSyncError(f"Failed to encode dictionary for upload: {e}") from e

    body = {
        "message": commit_message,
        "content": encoded_content,
        "sha": sha,
        "branch": config.BRANCH,
    }

    try:
        response = requests.put(url, headers=_headers(), json=body, timeout=15)
    except requests.exceptions.RequestException as e:
        raise CloudSyncError(f"Network error while contacting GitHub: {e}") from e

    if response.status_code in (409, 422):
        raise CloudSyncError(
            "GitHub rejected the update because the file changed since you "
            "last fetched it (sha mismatch). Reload the dictionary and try "
            "your edit again."
        )
    if response.status_code == 401:
        raise CloudSyncError(
            "GitHub rejected the request (401 Unauthorized). Check that "
            "GITHUB_TOKEN is valid and has 'repo' scope."
        )
    if response.status_code not in (200, 201):
        raise CloudSyncError(
            f"GitHub returned an unexpected status {response.status_code}: "
            f"{response.text[:300]}"
        )

    payload = response.json()
    new_sha = payload.get("content", {}).get("sha")
    if not new_sha:
        raise CloudSyncError("GitHub response after push was missing the new 'sha'.")
    return new_sha
