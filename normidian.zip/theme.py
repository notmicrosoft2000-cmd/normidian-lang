"""
theme.py
=========
Shared color palette and typography for both the Dictionary Manager and
the Translator app. Matte black base with a violet accent, per spec.
"""

COLOR_BG = "#121212"          # matte black background
COLOR_PANEL = "#1E1E1E"       # dark gray card containers
COLOR_FIELD = "#252526"       # input field backgrounds
COLOR_TEXT = "#E5E5E5"        # clean off-white text
COLOR_TEXT_MUTED = "#8A8A8E"
COLOR_ACCENT = "#7C3AED"      # sharp violet highlight
COLOR_ACCENT_HOVER = "#9333EA"
COLOR_BORDER = "#2E2E2E"
COLOR_BORDER_HOVER = "#7C3AED"
COLOR_DANGER = "#EF4444"
COLOR_DANGER_HOVER = "#F87171"
COLOR_SUCCESS = "#22C55E"

# Translator-specific
COLOR_OUTPUT_BG = "#1A162B"   # tinted deep indigo for the translation output box
COLOR_OUTPUT_TEXT = "#C4B5FD"

FONT_FAMILY = "Segoe UI"
FONT_MONO = "Consolas"

# Part-of-speech colors, reused for any future highlighting needs and for
# the dictionary browser's category labels.
POS_COLORS = {
    "nouns_living": "#4ADE80",
    "nouns_dead": "#38BDF8",
    "verbs": "#F472B6",
    "adjectives": "#FBBF24",
    "prepositions": "#A78BFA",
    "adverbs": "#FB923C",
    "conjunctions": "#2DD4BF",
    "pronouns": "#22D3EE",
    "article": "#94A3B8",
    "suffix": "#C4B5FD",
    "proper_noun": "#F0ABFC",
    "unknown": "#6B7280",
}

POS_LABELS = {
    "nouns_living": "Noun (Living)",
    "nouns_dead": "Noun (Dead)",
    "verbs": "Verb",
    "adjectives": "Adjective",
    "prepositions": "Preposition",
    "adverbs": "Adverb",
    "conjunctions": "Conjunction",
    "pronouns": "Pronoun",
    "article": "Article",
    "suffix": "Suffix",
    "proper_noun": "Name",
}
