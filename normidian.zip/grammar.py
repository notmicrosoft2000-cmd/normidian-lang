"""
grammar.py
===========
Fixed Normidian grammar constants: articles, noun case suffixes, adjective
agreement rules, pronouns, and verb conjugation rules. These are the core
language rules and are NOT derived from the dictionary -- they are
structural facts about Normidian itself, so they stay as Python constants
rather than living in the GitHub-hosted word list.
"""

# ---------------------------------------------------------------------------
# Centralized word-category lists. Every module (engine, colorizer, theme,
# translator_app, dictionary_manager) imports these instead of hard-coding
# its own tuple, so adding a new part-of-speech category only requires a
# change here (plus a POS_COLORS/POS_LABELS entry in theme.py).
# ---------------------------------------------------------------------------
CATEGORIES_WITH_MEANING = ("nouns_living", "nouns_dead", "verbs", "adjectives")
CATEGORIES_ROOT_ONLY = ("prepositions", "adverbs", "conjunctions")
ALL_WORD_CATEGORIES = CATEGORIES_WITH_MEANING + CATEGORIES_ROOT_ONLY


# ---------------------------------------------------------------------------
# Articles table (gender/case -> article)
# ---------------------------------------------------------------------------
ARTICLES = {
    ("living", "subject"): "ðse",
    ("dead", "subject"): "ðsaþ",
    ("living", "object"): "ðnes",
    ("dead", "object"): "ðsaþ",
    ("any", "possessor"): "ðœþ",
    ("any", "recipient"): "þœn",
    ("any", "plural"): "þasð",
}

WEAK_ADJ_SUFFIX = "ðn"
STRONG_ADJ = {
    "living_subject": "e",
    "living_object": "en",
    "dead_object": "re",
    "possessor_recipient": "þu",
}

PRESENT_SUFFIX = {
    "i": "ies",
    "you": "ðus",
    "he_she_it": "ƿues",
    "plural": ""  # bare root for we/you-all/they
}

PRONOUNS = {
    "i": "I",
    "you": "ðu",
    "he": "þses",
    "she": "ƿhes",
    "it": "þt",
    "we": "Þæ",
    "they": "ðhœy",
}

# Known noun/adjective suffix strings (used for stripping during reverse
# lookup and for two-tone suffix highlighting, if a UI wants it later).
NOUN_SUFFIXES = ["þnes", "þes", "þas", "þe"]
ADJ_WEAK_SUFFIX = ["ðn"]
ADJ_STRONG_SUFFIXES = ["en", "re", "þu", "e"]
VERB_PRESENT_SUFFIXES = ["ƿues", "ðus", "ies"]
PAST_MARKER = "ð"

# Negation prefix applied to a translated verb when the sentence was
# flagged as negated (e.g. "does not walk" -> negated ƿlak).
NEGATION_PREFIX = "ne-"

VOWELS_GROUP_1 = set("aei")  # -> œ
VOWELS_GROUP_2 = set("ou")   # -> æ

SPECIAL_CHARS = ["ð", "þ", "ƿ", "œ", "æ"]

# ---------------------------------------------------------------------------
# Contraction expansion table (Part 4.1: Contraction Cleansing)
# ---------------------------------------------------------------------------
CONTRACTIONS = {
    "don't": "do not", "doesn't": "does not", "didn't": "did not",
    "isn't": "is not", "aren't": "are not", "wasn't": "was not",
    "weren't": "were not", "it's": "it is", "he's": "he is",
    "she's": "she is", "they're": "they are", "we're": "we are",
    "i'm": "i am", "can't": "cannot", "won't": "will not",
    "shouldn't": "should not", "wouldn't": "would not", "couldn't": "could not",
    "haven't": "have not", "hasn't": "has not", "hadn't": "had not",
}

# Auxiliary "do"-support verbs that get stripped out when adjacent to "not"
# (Part 4.2: Auxiliary Elimination). These carry no independent meaning in
# Normidian -- negation is expressed with a prefix on the main verb instead.
DO_AUXILIARIES = {"do", "does", "did"}

# A small set of common irregular English plurals / past tenses, checked
# before falling back to regular suffix-stripping lemmatization.
IRREGULAR_PLURALS = {
    "men": "man", "women": "woman", "children": "child",
    "feet": "foot", "teeth": "tooth", "mice": "mouse",
    "geese": "goose", "wolves": "wolf", "knives": "knife",
}
IRREGULAR_VERB_PAST = {
    "gave": "give", "saw": "see", "went": "go", "was": "is", "were": "is",
}
