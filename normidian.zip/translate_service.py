"""
translate_service.py
======================
Normidian only has a hand-built dictionary going to/from English -- there's
no realistic way to hand-author Normidian<->Spanish, Normidian<->Japanese,
etc. Instead, when the user wants Normidian -> some other language, the
app bridges through English:

    Normidian --[NormidianEngine, offline]--> English --[this module, online]--> target language

This module only ever calls out for the second hop, and only when the
user explicitly picks a non-English target language in Settings. It talks
to the MyMemory Translation API (https://mymemory.translated.net/), which
is free and keyless, suitable for short phrases. Network failures are
caught and surfaced as a friendly error string rather than raised, so a
translation still displays (in English) even if the bridge call fails.
"""

import json
import urllib.parse
import urllib.request

API_URL = "https://api.mymemory.translated.net/get"


class TranslateServiceError(Exception):
    pass


def bridge_translate(text, target_lang, source_lang="en", timeout=8):
    """
    Translate `text` from `source_lang` to `target_lang` (ISO 639-1 codes).
    Returns the translated string. Raises TranslateServiceError on any
    network/parsing failure so the caller can fall back gracefully.
    """
    if not text.strip():
        return ""
    if target_lang == source_lang:
        return text

    params = {"q": text, "langpair": f"{source_lang}|{target_lang}"}
    url = f"{API_URL}?{urllib.parse.urlencode(params)}"

    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except Exception as e:
        raise TranslateServiceError(f"Couldn't reach the translation service: {e}") from e

    data = payload.get("responseData") or {}
    translated = data.get("translatedText")
    if not translated:
        raise TranslateServiceError("Translation service returned no result.")
    return translated
