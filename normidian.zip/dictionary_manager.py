#!/usr/bin/env python3
"""
dictionary_manager.py
=======================
Standalone desktop app (Tkinter, not a browser) for managing the
Normidian vocabulary stored in normidian_dictionary.json on GitHub.

This is the ONLY app that writes to the dictionary. It:
    - Fetches the dictionary from GitHub once at launch (with a manual
      "Refresh from GitHub" button to re-fetch on demand).
    - Lets you search/browse all words in a scrollable, animated list.
    - Adds new words via a form whose fields change based on the selected
      part of speech (nouns/verbs/adjectives need Meaning; prepositions/
      adverbs don't).
    - Blocks saving if the English word already exists anywhere in the
      dictionary (case-insensitive).
    - Deletes words with a smooth fade-out, and pushes the change to
      GitHub immediately.
    - Every add/delete triggers an explicit push to GitHub (Part 1 write
      method) -- nothing is "saved" only locally.

Run with:  python dictionary_manager.py
Requires:  GITHUB_TOKEN and REPO_NAME environment variables to be set
           (see the setup guide).
"""

import sys

if sys.platform.startswith("win"):
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            import ctypes
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

import json
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import config
import cloud_sync
import settings_store
from normidian_engine import NormidianEngine
from theme import (
    COLOR_BG, COLOR_PANEL, COLOR_FIELD, COLOR_TEXT, COLOR_TEXT_MUTED,
    COLOR_ACCENT, COLOR_ACCENT_HOVER, COLOR_BORDER, COLOR_DANGER,
    COLOR_DANGER_HOVER, COLOR_SUCCESS, FONT_FAMILY, FONT_MONO,
    POS_COLORS, POS_LABELS,
)
from widgets import HoverButton, FadeEntry, SpecialCharKeyboard, FadeCard, Tooltip, set_animations_enabled
from grammar import SPECIAL_CHARS, CATEGORIES_WITH_MEANING, CATEGORIES_ROOT_ONLY, ALL_WORD_CATEGORIES
from settings_dialog import SettingsDialog

CATEGORIES_WITH_MEANING = CATEGORIES_WITH_MEANING
CATEGORIES_ROOT_ONLY = CATEGORIES_ROOT_ONLY
ALL_CATEGORIES = ALL_WORD_CATEGORIES

SPECIAL_CHAR_TIPS = {
    "ð": "eth (Ð/ð) -- voiced 'th', as in this",
    "þ": "thorn (Þ/þ) -- unvoiced 'th', as in thin",
    "ƿ": "wynn (Ƿ/ƿ) -- pronounced like 'w'",
    "œ": "oe (Œ/œ) -- strong-verb vowel shift from a/e/i",
    "æ": "ash (Æ/æ) -- strong-verb vowel shift from o/u",
}


class DictionaryManagerApp:
    def __init__(self, root):
        self.root = root
        self.dictionary = {}
        self.current_sha = None
        self.engine = NormidianEngine({})
        self.settings = settings_store.load()
        self.category_var = tk.StringVar(value="nouns_dead")
        self.search_var = tk.StringVar(value="")
        self.filter_var = tk.StringVar(value="all")
        self._editing = None  # (category, english_key) while editing an existing word, else None
        self._stat_labels = {}

        self._setup_window()
        self._setup_styles()
        self._build_layout()
        set_animations_enabled(self.settings.get("animations_enabled", True))
        self._load_from_github(initial=True)

    # ------------------------------------------------------------------
    def _setup_window(self):
        self.root.title("Normidian Dictionary Manager")
        self.root.configure(bg=COLOR_BG)
        self.root.geometry("1100x720")
        self.root.minsize(860, 600)

    def _setup_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TFrame", background=COLOR_BG)
        style.configure(
            "Vertical.TScrollbar", background=COLOR_PANEL, troughcolor=COLOR_BG,
            bordercolor=COLOR_BG, arrowcolor=COLOR_TEXT_MUTED,
        )
        style.configure(
            "TRadiobutton", background=COLOR_PANEL, foreground=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        )
        style.map("TRadiobutton", background=[("active", COLOR_PANEL)])

    def _build_layout(self):
        header = tk.Frame(self.root, bg=COLOR_BG)
        header.pack(fill="x", padx=24, pady=(20, 10))

        tk.Label(
            header, text="Normidian Dictionary Manager", bg=COLOR_BG, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 20, "bold"),
        ).pack(side="left")

        self.sync_status_label = tk.Label(
            header, text="", bg=COLOR_BG, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 10),
        )
        self.sync_status_label.pack(side="left", padx=(16, 0), pady=(6, 0))

        HoverButton(
            header, text="⚙ Settings", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._open_settings,
        ).pack(side="right")
        HoverButton(
            header, text="Import JSON…", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._import_local_json,
        ).pack(side="right", padx=(0, 8))
        HoverButton(
            header, text="Export JSON…", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._export_local_json,
        ).pack(side="right", padx=(0, 8))
        HoverButton(
            header, text="↻ Refresh from GitHub", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=lambda: self._load_from_github(initial=False),
        ).pack(side="right", padx=(0, 8))

        if not config.is_configured():
            warn = tk.Frame(self.root, bg="#3A2400")
            warn.pack(fill="x", padx=24, pady=(0, 10))
            missing = ", ".join(config.missing_fields())
            tk.Label(
                warn, text=f"⚠ Missing environment variable(s): {missing}. "
                           f"Set them before this app can read or write the dictionary.",
                bg="#3A2400", fg="#FFD27A", font=(FONT_FAMILY, 10), anchor="w",
            ).pack(fill="x", padx=14, pady=8)

        stat_row = tk.Frame(self.root, bg=COLOR_BG)
        stat_row.pack(fill="x", padx=24, pady=(0, 14))
        for cat in ALL_CATEGORIES:
            badge = tk.Frame(stat_row, bg=COLOR_PANEL)
            badge.pack(side="left", padx=(0, 8))
            tk.Label(
                badge, text="●", bg=COLOR_PANEL, fg=POS_COLORS.get(cat, COLOR_TEXT),
                font=(FONT_FAMILY, 10),
            ).pack(side="left", padx=(10, 2), pady=6)
            count_label = tk.Label(
                badge, text=f"0 {POS_LABELS.get(cat, cat)}", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED,
                font=(FONT_FAMILY, 9, "bold"),
            )
            count_label.pack(side="left", padx=(0, 10), pady=6)
            self._stat_labels[cat] = count_label

        body = tk.Frame(self.root, bg=COLOR_BG)
        body.pack(fill="both", expand=True, padx=24, pady=(0, 20))
        body.columnconfigure(0, weight=0)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        self._build_form_panel(body)
        self._build_list_panel(body)

    # ------------------------------------------------------------------
    # LEFT: Add/Update form
    # ------------------------------------------------------------------
    def _build_form_panel(self, parent):
        panel = tk.Frame(parent, bg=COLOR_PANEL, width=330)
        panel.grid(row=0, column=0, sticky="ns", padx=(0, 12))
        panel.grid_propagate(False)

        self.form_title_label = tk.Label(
            panel, text="Add a New Word", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 14, "bold"),
        )
        self.form_title_label.pack(anchor="w", padx=18, pady=(18, 4))
        tk.Label(
            panel, text="Changes are pushed straight to GitHub.",
            bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 9),
        ).pack(anchor="w", padx=18, pady=(0, 14))

        tk.Label(
            panel, text="Part of Speech:", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        ).pack(anchor="w", padx=18)

        pos_dropdown = ttk.Combobox(
            panel, textvariable=self.category_var, state="readonly",
            values=[POS_LABELS.get(c, c) for c in ALL_CATEGORIES],
            font=(FONT_FAMILY, 10),
        )
        # Combobox needs a display->key map since it shows labels, not keys
        self._pos_label_to_key = {POS_LABELS.get(c, c): c for c in ALL_CATEGORIES}
        pos_dropdown.set(POS_LABELS["nouns_dead"])
        pos_dropdown.pack(fill="x", padx=18, pady=(4, 12))
        pos_dropdown.bind("<<ComboboxSelected>>", self._on_pos_changed)
        self._pos_dropdown = pos_dropdown

        tk.Label(
            panel, text="English word:", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        ).pack(anchor="w", padx=18)
        self.english_entry = FadeEntry(panel)
        self.english_entry.pack(fill="x", padx=18, pady=(4, 12), ipady=6)

        tk.Label(
            panel, text="Normidian Root:", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        ).pack(anchor="w", padx=18)
        self.root_entry = FadeEntry(panel)
        self.root_entry.pack(fill="x", padx=18, pady=(4, 12), ipady=6)

        self.meaning_label = tk.Label(
            panel, text="Meaning:", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        )
        self.meaning_label.pack(anchor="w", padx=18)
        self.meaning_entry = FadeEntry(panel)
        self.meaning_entry.pack(fill="x", padx=18, pady=(4, 12), ipady=6)

        tk.Label(
            panel, text="Insert special character:", bg=COLOR_PANEL,
            fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 8),
        ).pack(anchor="w", padx=18, pady=(2, 2))
        kb = SpecialCharKeyboard(
            panel, targets=[self.english_entry, self.root_entry, self.meaning_entry],
            special_chars=SPECIAL_CHARS,
        )
        kb.pack(anchor="w", padx=18, pady=(0, 14))
        for child in kb.winfo_children():
            tip = SPECIAL_CHAR_TIPS.get(child["text"])
            if tip:
                Tooltip(child, tip)

        self.form_status_label = tk.Label(
            panel, text="", bg=COLOR_PANEL, fg=COLOR_DANGER, font=(FONT_FAMILY, 9),
            anchor="w", justify="left", wraplength=290,
        )
        self.form_status_label.pack(fill="x", padx=18, pady=(0, 8))

        btn_row = tk.Frame(panel, bg=COLOR_PANEL)
        btn_row.pack(fill="x", padx=18, pady=(0, 20))
        self.save_btn = HoverButton(
            btn_row, text="Save Word", bg=COLOR_ACCENT, hover_bg=COLOR_ACCENT_HOVER,
            command=self._save_word,
        )
        self.save_btn.pack(side="left")
        HoverButton(
            btn_row, text="Clear", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._clear_form,
        ).pack(side="left", padx=(8, 0))
        self.cancel_edit_btn = HoverButton(
            btn_row, text="Cancel Edit", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self._clear_form,
        )

        self._on_pos_changed()
        for entry in (self.english_entry, self.root_entry, self.meaning_entry):
            entry.bind("<Return>", lambda e: self._save_word())

    def _on_pos_changed(self, _event=None):
        label = self._pos_dropdown.get()
        category = self._pos_label_to_key.get(label, "nouns_dead")
        self.category_var.set(category)
        if category in CATEGORIES_ROOT_ONLY:
            self.meaning_label.pack_forget()
            self.meaning_entry.pack_forget()
        else:
            self.meaning_label.pack(anchor="w", padx=18)
            self.meaning_entry.pack(fill="x", padx=18, pady=(4, 12), ipady=6)

    def _clear_form(self):
        self.english_entry.delete(0, "end")
        self.root_entry.delete(0, "end")
        self.meaning_entry.delete(0, "end")
        self.form_status_label.config(text="")
        was_editing = self._editing is not None
        self._editing = None
        self.form_title_label.config(text="Add a New Word")
        self.save_btn.config(text="Save Word")
        self.cancel_edit_btn.pack_forget()
        if was_editing:
            self._refresh_list()

    def _save_word(self):
        category = self.category_var.get()
        english_word = self.english_entry.get().strip()
        root_word = self.root_entry.get().strip()
        meaning = self.meaning_entry.get().strip()

        if not english_word or not root_word:
            self.form_status_label.config(
                fg=COLOR_DANGER, text="English word and Normidian Root are both required."
            )
            return
        if category in CATEGORIES_WITH_MEANING and not meaning:
            self.form_status_label.config(
                fg=COLOR_DANGER, text="Meaning is required for this part of speech."
            )
            return

        old_category, old_key = self._editing if self._editing else (None, None)
        is_rename = bool(old_key) and english_word.lower() != old_key.lower()

        # Validation: block duplicate English words across the whole dictionary,
        # unless we're editing that exact word and its name hasn't changed.
        if self.engine.word_exists(english_word) and (old_key is None or is_rename):
            self.form_status_label.config(
                fg=COLOR_DANGER,
                text=f'"{english_word}" already exists in the dictionary. '
                     f"Delete it first if you want to replace it.",
            )
            return

        entry = {"Root": root_word}
        if category in CATEGORIES_WITH_MEANING:
            entry["Meaning"] = meaning

        if old_key is not None:
            removed_entry = self.dictionary.get(old_category, {}).pop(old_key, None)
            self.dictionary.setdefault(category, {})[english_word] = entry
            self.engine.set_dictionary(self.dictionary)

            if not self._push_to_github(f"Update word: {old_key} -> {english_word}"):
                # Roll back: remove the new entry, restore the old one
                self.dictionary.get(category, {}).pop(english_word, None)
                if removed_entry is not None:
                    self.dictionary.setdefault(old_category, {})[old_key] = removed_entry
                self.engine.set_dictionary(self.dictionary)
                return

            self.form_status_label.config(fg=COLOR_SUCCESS, text=f'"{english_word}" updated and synced.')
        else:
            self.dictionary.setdefault(category, {})[english_word] = entry
            self.engine.set_dictionary(self.dictionary)

            if not self._push_to_github(f"Add word: {english_word}"):
                # Roll back the in-memory add if the push failed, so the local
                # state doesn't drift from what's actually on GitHub.
                del self.dictionary[category][english_word]
                self.engine.set_dictionary(self.dictionary)
                return

            self.form_status_label.config(fg=COLOR_SUCCESS, text=f'"{english_word}" saved and synced.')

        self._editing = None
        self.form_title_label.config(text="Add a New Word")
        self.save_btn.config(text="Save Word")
        self.cancel_edit_btn.pack_forget()
        self._clear_form_fields_only()
        self._refresh_list(animate_new=english_word)

    def _clear_form_fields_only(self):
        self.english_entry.delete(0, "end")
        self.root_entry.delete(0, "end")
        self.meaning_entry.delete(0, "end")

    def _load_word_into_form(self, category, english_key, entry):
        self._editing = (category, english_key)
        label = POS_LABELS.get(category, category)
        self._pos_dropdown.set(label)
        self._on_pos_changed()

        self.english_entry.delete(0, "end")
        self.english_entry.insert(0, english_key)
        self.root_entry.delete(0, "end")
        self.root_entry.insert(0, entry.get("Root", ""))
        self.meaning_entry.delete(0, "end")
        self.meaning_entry.insert(0, entry.get("Meaning", ""))

        self.form_title_label.config(text=f'Editing "{english_key}"')
        self.save_btn.config(text="Update Word")
        self.cancel_edit_btn.pack(side="left", padx=(8, 0))
        self.form_status_label.config(text="")
        self.english_entry.focus_set()

    # ------------------------------------------------------------------
    # RIGHT: Search + scrollable word list
    # ------------------------------------------------------------------
    def _build_list_panel(self, parent):
        panel = tk.Frame(parent, bg=COLOR_PANEL)
        panel.grid(row=0, column=1, sticky="nsew")

        top_row = tk.Frame(panel, bg=COLOR_PANEL)
        top_row.pack(fill="x", padx=18, pady=(18, 8))

        tk.Label(
            top_row, text="Dictionary Browser", bg=COLOR_PANEL, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 14, "bold"),
        ).pack(side="left")

        self.word_count_label = tk.Label(
            top_row, text="", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 9),
        )
        self.word_count_label.pack(side="left", padx=(10, 0), pady=(4, 0))

        search_row = tk.Frame(panel, bg=COLOR_PANEL)
        search_row.pack(fill="x", padx=18, pady=(0, 8))
        search_entry = FadeEntry(search_row, textvariable=self.search_var)
        search_entry.pack(side="left", fill="x", expand=True, ipady=6)
        search_entry.insert(0, "")
        tk.Label(search_row, text="🔍", bg=COLOR_PANEL, fg=COLOR_TEXT_MUTED).pack(side="left", padx=(8, 0))
        self.search_var.trace_add("write", lambda *a: self._refresh_list())

        filter_row = tk.Frame(panel, bg=COLOR_PANEL)
        filter_row.pack(fill="x", padx=18, pady=(0, 10))
        options = [("All", "all")] + [(POS_LABELS[c], c) for c in ALL_CATEGORIES]
        for label, value in options:
            tk.Radiobutton(
                filter_row, text=label, value=value, variable=self.filter_var,
                bg=COLOR_PANEL, fg=COLOR_TEXT, selectcolor=COLOR_FIELD,
                activebackground=COLOR_PANEL, activeforeground=COLOR_TEXT,
                font=(FONT_FAMILY, 9), command=self._refresh_list,
            ).pack(side="left", padx=(0, 8))

        list_scroll_frame = tk.Frame(panel, bg=COLOR_PANEL)
        list_scroll_frame.pack(fill="both", expand=True, padx=18, pady=(0, 16))

        canvas = tk.Canvas(list_scroll_frame, bg=COLOR_PANEL, highlightthickness=0)
        scrollbar = ttk.Scrollbar(list_scroll_frame, orient="vertical", command=canvas.yview)
        self.list_inner = tk.Frame(canvas, bg=COLOR_PANEL)

        self.list_inner.bind(
            "<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas_window = canvas.create_window((0, 0), window=self.list_inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        def _resize_inner(event):
            canvas.itemconfig(canvas_window, width=event.width)

        canvas.bind("<Configure>", _resize_inner)

        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def _refresh_list(self, animate_new=None):
        for child in self.list_inner.winfo_children():
            child.destroy()

        query = self.search_var.get().strip().lower()
        chosen_filter = self.filter_var.get()
        categories = ALL_CATEGORIES if chosen_filter == "all" else [chosen_filter]

        total_shown = 0
        total_all = sum(len(self.dictionary.get(c, {})) for c in ALL_CATEGORIES)

        for cat in categories:
            entries = self.dictionary.get(cat, {})
            matches = {
                k: v for k, v in entries.items()
                if not query or query in k.lower() or query in str(v.get("Root", "")).lower()
            }
            if not matches:
                continue

            cat_label = tk.Label(
                self.list_inner, text=POS_LABELS.get(cat, cat), bg=COLOR_PANEL,
                fg=POS_COLORS.get(cat, COLOR_TEXT), font=(FONT_FAMILY, 11, "bold"),
                anchor="w",
            )
            cat_label.pack(fill="x", pady=(12, 4))

            for eng_key in sorted(matches.keys()):
                entry = matches[eng_key]
                card = self._build_word_card(self.list_inner, cat, eng_key, entry)
                card.pack(fill="x", pady=2)
                if animate_new == eng_key:
                    card.animate_in()
                total_shown += 1

        self.word_count_label.config(text=f"{total_shown} shown / {total_all} total")

        for cat in ALL_CATEGORIES:
            count = len(self.dictionary.get(cat, {}))
            label = self._stat_labels.get(cat)
            if label:
                label.config(text=f"{count} {POS_LABELS.get(cat, cat)}")

    def _build_word_card(self, parent, category, english_key, entry):
        card = FadeCard(parent, height=44)
        is_being_edited = self._editing == (category, english_key)
        base_bg = COLOR_FIELD if is_being_edited else COLOR_PANEL
        card.configure(bg=base_bg)

        row_widgets = []

        eng_label = tk.Label(
            card, text=english_key, bg=base_bg, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10), anchor="w", width=16, cursor="hand2",
        )
        eng_label.pack(side="left", padx=(10, 6))
        row_widgets.append(eng_label)

        root_label = tk.Label(
            card, text=entry.get("Root", ""), bg=base_bg, fg=POS_COLORS.get(category, COLOR_TEXT),
            font=(FONT_MONO, 10), anchor="w", width=14, cursor="hand2",
        )
        root_label.pack(side="left", padx=6)
        row_widgets.append(root_label)

        meaning_text = entry.get("Meaning", "")
        meaning_label = tk.Label(
            card, text=meaning_text, bg=base_bg, fg=COLOR_TEXT_MUTED,
            font=(FONT_FAMILY, 9), anchor="w", cursor="hand2",
        )
        meaning_label.pack(side="left", padx=6, fill="x", expand=True)
        row_widgets.append(meaning_label)

        edit_hint = tk.Label(
            card, text="✎ Edit", bg=base_bg, fg=COLOR_TEXT_MUTED,
            font=(FONT_FAMILY, 8, "italic"),
        )
        edit_hint.pack(side="right", padx=(6, 4))
        row_widgets.append(edit_hint)

        del_btn = tk.Label(
            card, text="✕ Delete", bg=base_bg, fg=COLOR_DANGER,
            font=(FONT_FAMILY, 9, "bold"), cursor="hand2",
        )
        del_btn.pack(side="right", padx=(6, 12))
        del_btn.bind(
            "<Enter>", lambda e: del_btn.config(fg=COLOR_DANGER_HOVER)
        )
        del_btn.bind(
            "<Leave>", lambda e: del_btn.config(fg=COLOR_DANGER)
        )
        del_btn.bind(
            "<Button-1>", lambda e, c=category, k=english_key, card=card: self._delete_word(c, k, card)
        )

        def _highlight(_e=None):
            hover_bg = "#33384A"
            card.configure(bg=hover_bg)
            del_btn.configure(bg=hover_bg)
            for w in row_widgets:
                w.configure(bg=hover_bg)

        def _unhighlight(_e=None):
            card.configure(bg=base_bg)
            del_btn.configure(bg=base_bg)
            for w in row_widgets:
                w.configure(bg=base_bg)

        def _edit(_e=None):
            self._load_word_into_form(category, english_key, entry)

        for w in [card, eng_label, root_label, meaning_label, edit_hint]:
            w.bind("<Enter>", _highlight)
            w.bind("<Leave>", _unhighlight)
            w.bind("<Button-1>", _edit)

        return card

    def _delete_word(self, category, english_key, card):
        confirm = messagebox.askyesno(
            "Remove Word", f'Remove "{english_key}" from the dictionary?\n\n'
                           f"This will be pushed to GitHub immediately."
        )
        if not confirm:
            return

        def _actually_delete():
            if english_key in self.dictionary.get(category, {}):
                removed_entry = self.dictionary[category].pop(english_key)
                self.engine.set_dictionary(self.dictionary)
                if not self._push_to_github(f"Remove word: {english_key}"):
                    # Roll back if the push failed
                    self.dictionary[category][english_key] = removed_entry
                    self.engine.set_dictionary(self.dictionary)
                    self._refresh_list()
                    return
            if self._editing == (category, english_key):
                self._clear_form()
            self._refresh_list()

        card.animate_out(on_complete=_actually_delete)

    # ------------------------------------------------------------------
    # GitHub sync plumbing
    # ------------------------------------------------------------------
    def _load_from_github(self, initial=False):
        if not config.is_configured():
            self.sync_status_label.config(text="Not configured -- set GITHUB_TOKEN and REPO_NAME.")
            if initial:
                # Start with an empty dictionary so the app is still usable
                # (read-only feeling) until configured.
                self.dictionary = {c: {} for c in ALL_CATEGORIES}
                self.engine.set_dictionary(self.dictionary)
                self._refresh_list()
            return

        self.sync_status_label.config(text="Fetching from GitHub…")
        self.root.update_idletasks()
        try:
            data, sha = cloud_sync.fetch_dictionary()
            self.dictionary = data
            self.current_sha = sha
            for c in ALL_CATEGORIES:
                self.dictionary.setdefault(c, {})
            self.engine.set_dictionary(self.dictionary)
            self.sync_status_label.config(text="✓ Synced with GitHub", fg=COLOR_SUCCESS)
            self._refresh_list()
        except cloud_sync.CloudSyncError as e:
            self.sync_status_label.config(text="⚠ Sync failed", fg=COLOR_DANGER)
            messagebox.showerror("GitHub Sync Failed", str(e))
            if initial:
                self.dictionary = {c: {} for c in ALL_CATEGORIES}
                self.engine.set_dictionary(self.dictionary)
                self._refresh_list()

    def _push_to_github(self, commit_message):
        """Returns True on success, False on failure (and shows a dialog)."""
        if not config.is_configured():
            messagebox.showerror(
                "Not Configured",
                "GITHUB_TOKEN and REPO_NAME must be set before you can save changes.",
            )
            return False
        if self.current_sha is None:
            messagebox.showerror(
                "Not Synced",
                "The dictionary hasn't been loaded from GitHub yet. Click "
                "'Refresh from GitHub' first.",
            )
            return False

        self.sync_status_label.config(text="Pushing to GitHub…", fg=COLOR_TEXT_MUTED)
        self.root.update_idletasks()
        try:
            new_sha = cloud_sync.push_dictionary(self.dictionary, self.current_sha, commit_message)
            self.current_sha = new_sha
            self.sync_status_label.config(text="✓ Synced with GitHub", fg=COLOR_SUCCESS)
            return True
        except cloud_sync.CloudSyncError as e:
            self.sync_status_label.config(text="⚠ Push failed", fg=COLOR_DANGER)
            messagebox.showerror("GitHub Push Failed", str(e))
            return False


    # ------------------------------------------------------------------
    # Settings dialog (font size, animations, speech -- shared with the
    # Translator app; the Normidian->other-language bridge option is
    # hidden here since it's not relevant to editing the dictionary).
    # ------------------------------------------------------------------
    def _open_settings(self):
        def _apply(new_settings):
            self.settings = new_settings
            set_animations_enabled(self.settings.get("animations_enabled", True))
        SettingsDialog(self.root, self.settings, _apply, show_translation_options=False)

    # ------------------------------------------------------------------
    # Local JSON backup (independent of GitHub) -- lets a user snapshot
    # or restore the dictionary from their own disk, e.g. before a big
    # batch of edits, or to hand a colleague a copy without GitHub access.
    # ------------------------------------------------------------------
    def _export_local_json(self):
        path = filedialog.asksaveasfilename(
            title="Export dictionary as JSON",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")],
            initialfile="normidian_dictionary_backup.json",
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.dictionary, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("Exported", f"Dictionary saved to:\n{path}")
        except OSError as e:
            messagebox.showerror("Export Failed", str(e))

    def _import_local_json(self):
        path = filedialog.askopenfilename(
            title="Import dictionary from JSON", filetypes=[("JSON files", "*.json")],
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            messagebox.showerror("Import Failed", f"Couldn't read that file:\n{e}")
            return
        if not isinstance(data, dict):
            messagebox.showerror("Import Failed", "That file isn't a valid dictionary JSON object.")
            return

        confirm = messagebox.askyesno(
            "Import Dictionary",
            "This replaces the dictionary currently loaded in this app (in memory) "
            "with the contents of the chosen file. It is NOT pushed to GitHub until "
            "you make an edit that triggers a save. Continue?",
        )
        if not confirm:
            return

        for cat in ALL_CATEGORIES:
            data.setdefault(cat, {})
        self.dictionary = data
        self.engine.set_dictionary(self.dictionary)
        self.sync_status_label.config(
            text="Loaded from local file (not yet pushed to GitHub)", fg=COLOR_TEXT_MUTED,
        )
        self._refresh_list()


def main():
    root = tk.Tk()
    app = DictionaryManagerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
