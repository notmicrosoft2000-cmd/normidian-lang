"""
settings_dialog.py
====================
One shared Settings window used by both translator_app.py and
dictionary_manager.py, so appearance/behavior preferences (font size,
animations, text-to-speech, default direction/target language) live in
one place instead of being duplicated across the two apps.

Callers pass in the current settings dict and an `on_apply(settings)`
callback; this dialog never touches the dictionary or GitHub -- it only
reads/writes settings_store.py's local JSON file.
"""

import tkinter as tk
from tkinter import ttk

import settings_store
from theme import (
    COLOR_BG, COLOR_PANEL, COLOR_FIELD, COLOR_TEXT, COLOR_TEXT_MUTED,
    COLOR_ACCENT, COLOR_ACCENT_HOVER, COLOR_BORDER, FONT_FAMILY,
)
from widgets import HoverButton, ToggleSwitch, Tooltip


class SettingsDialog(tk.Toplevel):
    def __init__(self, master, current_settings, on_apply, show_translation_options=True):
        super().__init__(master)
        self.title("Settings")
        self.configure(bg=COLOR_BG)
        self.geometry("420x560")
        self.minsize(380, 460)
        self.transient(master)
        self.grab_set()

        self.on_apply = on_apply
        self.values = dict(current_settings)
        self.show_translation_options = show_translation_options

        self._vars = {}
        self._build()
        self.bind("<Escape>", lambda e: self.destroy())

    def _section_label(self, parent, text):
        tk.Label(
            parent, text=text, bg=COLOR_BG, fg=COLOR_ACCENT_HOVER,
            font=(FONT_FAMILY, 11, "bold"), anchor="w",
        ).pack(fill="x", padx=20, pady=(18, 6))

    def _toggle_row(self, parent, label, key, tooltip=None):
        row = tk.Frame(parent, bg=COLOR_BG)
        row.pack(fill="x", padx=20, pady=4)
        lbl = tk.Label(
            row, text=label, bg=COLOR_BG, fg=COLOR_TEXT, font=(FONT_FAMILY, 10), anchor="w",
        )
        lbl.pack(side="left")
        var = tk.BooleanVar(value=bool(self.values.get(key)))
        self._vars[key] = var
        switch = ToggleSwitch(row, var, command=lambda v, k=key: self.values.__setitem__(k, v))
        switch.pack(side="right")
        if tooltip:
            Tooltip(lbl, tooltip)
            Tooltip(switch, tooltip)

    def _build(self):
        canvas = tk.Canvas(self, bg=COLOR_BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        scroll = tk.Frame(canvas, bg=COLOR_BG)
        scroll.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        win = canvas.create_window((0, 0), window=scroll, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(win, width=e.width))
        canvas.pack(side="top", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        tk.Label(
            scroll, text="Settings", bg=COLOR_BG, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 16, "bold"),
        ).pack(anchor="w", padx=20, pady=(18, 0))
        tk.Label(
            scroll, text="Saved on this device only.", bg=COLOR_BG, fg=COLOR_TEXT_MUTED,
            font=(FONT_FAMILY, 8, "italic"),
        ).pack(anchor="w", padx=20, pady=(0, 6))

        # --- Appearance ---
        self._section_label(scroll, "Appearance")

        font_row = tk.Frame(scroll, bg=COLOR_BG)
        font_row.pack(fill="x", padx=20, pady=4)
        tk.Label(
            font_row, text="Text size", bg=COLOR_BG, fg=COLOR_TEXT, font=(FONT_FAMILY, 10),
        ).pack(anchor="w")
        self._font_var = tk.StringVar()
        current_label = next(
            (label for label, scale in settings_store.FONT_SCALE_CHOICES
             if abs(scale - self.values.get("font_scale", 1.0)) < 0.01),
            "Medium",
        )
        self._font_var.set(current_label)
        font_dropdown = ttk.Combobox(
            font_row, textvariable=self._font_var, state="readonly",
            values=[label for label, _ in settings_store.FONT_SCALE_CHOICES],
            font=(FONT_FAMILY, 10),
        )
        font_dropdown.pack(fill="x", pady=(4, 0))

        def _on_font_change(_e=None):
            label = self._font_var.get()
            scale = next((s for l, s in settings_store.FONT_SCALE_CHOICES if l == label), 1.0)
            self.values["font_scale"] = scale
        font_dropdown.bind("<<ComboboxSelected>>", _on_font_change)

        self._toggle_row(
            scroll, "Smooth animations", "animations_enabled",
            tooltip="Fade/slide effects on hover, focus, and add/delete. "
                    "Turn off for a snappier, fully instant UI.",
        )
        self._toggle_row(
            scroll, "High-contrast focus outlines", "high_contrast",
            tooltip="Thicker, brighter borders around the focused field or "
                    "button -- useful for low-vision or keyboard navigation.",
        )

        # --- Speech ---
        self._section_label(scroll, "Speech")
        self._toggle_row(
            scroll, "Auto-read translation aloud", "auto_read_aloud",
            tooltip="Speaks the output automatically once a translation "
                    "finishes, instead of waiting for the Read Aloud button.",
        )

        rate_row = tk.Frame(scroll, bg=COLOR_BG)
        rate_row.pack(fill="x", padx=20, pady=(6, 4))
        tk.Label(
            rate_row, text="Speech rate (words/min)", bg=COLOR_BG, fg=COLOR_TEXT,
            font=(FONT_FAMILY, 10),
        ).pack(anchor="w")
        self._rate_var = tk.IntVar(value=int(self.values.get("tts_rate", 175)))
        rate_scale = tk.Scale(
            rate_row, from_=100, to=260, orient="horizontal", variable=self._rate_var,
            bg=COLOR_BG, fg=COLOR_TEXT, troughcolor=COLOR_FIELD, highlightthickness=0,
            font=(FONT_FAMILY, 8), showvalue=True,
            command=lambda v: self.values.__setitem__("tts_rate", int(float(v))),
        )
        rate_scale.pack(fill="x")

        # --- Translation (Translator app only) ---
        if self.show_translation_options:
            self._section_label(scroll, "Translation")

            dir_row = tk.Frame(scroll, bg=COLOR_BG)
            dir_row.pack(fill="x", padx=20, pady=4)
            tk.Label(
                dir_row, text="Default direction on launch", bg=COLOR_BG, fg=COLOR_TEXT,
                font=(FONT_FAMILY, 10),
            ).pack(anchor="w")
            self._dir_var = tk.StringVar(
                value="English → Normidian" if self.values.get("default_direction") == "en_to_no"
                else "Normidian → English"
            )
            dir_dropdown = ttk.Combobox(
                dir_row, textvariable=self._dir_var, state="readonly",
                values=["English → Normidian", "Normidian → English"], font=(FONT_FAMILY, 10),
            )
            dir_dropdown.pack(fill="x", pady=(4, 0))

            def _on_dir_change(_e=None):
                self.values["default_direction"] = (
                    "en_to_no" if self._dir_var.get().startswith("English") else "no_to_en"
                )
            dir_dropdown.bind("<<ComboboxSelected>>", _on_dir_change)

            lang_row = tk.Frame(scroll, bg=COLOR_BG)
            lang_row.pack(fill="x", padx=20, pady=(10, 4))
            tk.Label(
                lang_row, text="Bridge Normidian → English output into:",
                bg=COLOR_BG, fg=COLOR_TEXT, font=(FONT_FAMILY, 10), anchor="w", wraplength=360,
                justify="left",
            ).pack(anchor="w")
            tk.Label(
                lang_row, text="Requires internet. Normidian → English is done offline; "
                               "this adds a second online hop, English → your chosen language.",
                bg=COLOR_BG, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 8, "italic"),
                wraplength=360, justify="left",
            ).pack(anchor="w", pady=(2, 4))

            code_to_label = {code: label for label, code in settings_store.BRIDGE_LANGUAGES}
            self._lang_var = tk.StringVar(
                value=code_to_label.get(self.values.get("target_language", "en"), "English")
            )
            lang_dropdown = ttk.Combobox(
                lang_row, textvariable=self._lang_var, state="readonly",
                values=[label for label, _ in settings_store.BRIDGE_LANGUAGES], font=(FONT_FAMILY, 10),
            )
            lang_dropdown.pack(fill="x")

            def _on_lang_change(_e=None):
                label = self._lang_var.get()
                code = next((c for l, c in settings_store.BRIDGE_LANGUAGES if l == label), "en")
                self.values["target_language"] = code
            lang_dropdown.bind("<<ComboboxSelected>>", _on_lang_change)

        # --- Footer buttons ---
        footer = tk.Frame(scroll, bg=COLOR_BG)
        footer.pack(fill="x", padx=20, pady=(24, 20))
        HoverButton(
            footer, text="Save", bg=COLOR_ACCENT, hover_bg=COLOR_ACCENT_HOVER,
            command=self._save,
        ).pack(side="left")
        HoverButton(
            footer, text="Cancel", bg=COLOR_FIELD, hover_bg="#3A3A3A",
            command=self.destroy,
        ).pack(side="left", padx=(8, 0))
        self._status = tk.Label(
            footer, text="", bg=COLOR_BG, fg=COLOR_TEXT_MUTED, font=(FONT_FAMILY, 9),
        )
        self._status.pack(side="left", padx=(10, 0))

    def _save(self):
        settings_store.save(self.values)
        if self.on_apply:
            self.on_apply(dict(self.values))
        self.destroy()
