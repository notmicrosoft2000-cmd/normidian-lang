"""
widgets.py
===========
Small reusable Tkinter widgets and animation helpers shared by both the
Dictionary Manager and the Translator app: hover-animated buttons and
entry fields (soft border-color fade), and simple fade/slide helpers for
add/delete actions in the dictionary list.

Tkinter has no native CSS transitions, so "soft fade" here is implemented
as a short chain of scheduled `.after()` calls that step the color (or a
widget's height/alpha proxy) across a series of intermediate values --
functionally equivalent to `transition: border-color 0.25s ease-in-out`.
"""

import tkinter as tk

from theme import (
    COLOR_BG, COLOR_PANEL, COLOR_FIELD, COLOR_TEXT, COLOR_TEXT_MUTED,
    COLOR_ACCENT, COLOR_ACCENT_HOVER, COLOR_BORDER, COLOR_BORDER_HOVER,
    COLOR_DANGER, COLOR_DANGER_HOVER, FONT_FAMILY,
)

FADE_STEPS = 10
FADE_DURATION_MS = 250  # matches the requested 0.25s ease-in-out

# Global switch (set from Settings) -- when False, every widget below
# jumps straight to its end state instead of animating, for a snappier
# feel or for reduced-motion accessibility preferences.
ANIMATIONS_ENABLED = True


def set_animations_enabled(enabled):
    global ANIMATIONS_ENABLED
    ANIMATIONS_ENABLED = bool(enabled)


def _hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))


def _rgb_to_hex(rgb):
    return "#{:02X}{:02X}{:02X}".format(*[max(0, min(255, int(c))) for c in rgb])


def _lerp_color(c1, c2, t):
    r1, g1, b1 = _hex_to_rgb(c1)
    r2, g2, b2 = _hex_to_rgb(c2)
    return _rgb_to_hex((r1 + (r2 - r1) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t))


def _ease_in_out(t):
    """Cubic ease-in-out, matching CSS 'ease-in-out' timing curve closely enough."""
    return t * t * (3 - 2 * t)


class _BorderFadeMixin:
    """
    Mixin that animates a widget's `highlightbackground` color smoothly
    between a resting border color and a hover border color, using a
    scheduled step chain rather than an instant swap.
    """

    def _start_border_fade(self, widget, from_color, to_color, steps=FADE_STEPS,
                            duration_ms=FADE_DURATION_MS):
        if not ANIMATIONS_ENABLED:
            try:
                widget.configure(highlightbackground=to_color, highlightcolor=to_color)
            except tk.TclError:
                pass
            return

        job_attr = f"_fade_job_{id(widget)}"
        existing_job = getattr(widget, job_attr, None)
        if existing_job:
            try:
                widget.after_cancel(existing_job)
            except Exception:
                pass

        step_delay = max(1, duration_ms // steps)

        def _step(i=0):
            t = _ease_in_out(i / steps)
            color = _lerp_color(from_color, to_color, t)
            try:
                widget.configure(highlightbackground=color, highlightcolor=color)
            except tk.TclError:
                return
            if i < steps:
                job = widget.after(step_delay, lambda: _step(i + 1))
                setattr(widget, job_attr, job)
            else:
                setattr(widget, job_attr, None)

        _step(0)


class HoverButton(tk.Button, _BorderFadeMixin):
    """A tk.Button with a smooth violet-border fade on hover (per spec:
    transition: border-color 0.25s ease-in-out)."""

    def __init__(self, master, bg=COLOR_ACCENT, hover_bg=COLOR_ACCENT_HOVER,
                 fg=COLOR_TEXT, **kwargs):
        font = kwargs.pop("font", (FONT_FAMILY, 10, "bold"))
        super().__init__(
            master,
            bg=bg,
            fg=fg,
            activebackground=hover_bg,
            activeforeground=fg,
            relief="flat",
            bd=0,
            padx=14,
            pady=8,
            font=font,
            cursor="hand2",
            highlightthickness=2,
            highlightbackground=bg,
            highlightcolor=bg,
            **kwargs,
        )
        self._bg = bg
        self._hover_bg = hover_bg
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)

    def _on_enter(self, _event):
        if self["state"] != "disabled":
            self.config(bg=self._hover_bg)
            self._start_border_fade(self, self._bg, self._hover_bg)

    def _on_leave(self, _event):
        if self["state"] != "disabled":
            self.config(bg=self._bg)
            self._start_border_fade(self, self._hover_bg, self._bg)


class FadeEntry(tk.Entry, _BorderFadeMixin):
    """
    A tk.Entry whose border fades to the violet accent color on focus/hover
    (fields don't have a real "hover vs focus" distinction visually here,
    so both trigger the same fade for a consistent feel).
    """

    def __init__(self, master, **kwargs):
        super().__init__(
            master,
            bg=COLOR_FIELD,
            fg=COLOR_TEXT,
            insertbackground=COLOR_TEXT,
            relief="flat",
            font=(FONT_FAMILY, 11),
            highlightthickness=2,
            highlightbackground=COLOR_BORDER,
            highlightcolor=COLOR_BORDER,
            **kwargs,
        )
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<FocusIn>", self._on_enter)
        self.bind("<FocusOut>", self._on_leave)

    def _on_enter(self, _event):
        self._start_border_fade(self, COLOR_BORDER, COLOR_BORDER_HOVER)

    def _on_leave(self, _event):
        if self is self.focus_get():
            return
        self._start_border_fade(self, COLOR_BORDER_HOVER, COLOR_BORDER)


class SpecialCharKeyboard(tk.Frame):
    """A small row of buttons for the 5 special Normidian characters,
    inserting the clicked character into whichever target Entry has focus."""

    def __init__(self, master, targets, special_chars, **kwargs):
        super().__init__(master, bg=COLOR_PANEL, **kwargs)
        self.targets = targets
        for ch in special_chars:
            btn = HoverButton(
                self, text=ch, bg=COLOR_FIELD, hover_bg=COLOR_ACCENT,
                fg=COLOR_TEXT, width=3,
                command=lambda c=ch: self._insert_char(c),
            )
            btn.pack(side="left", padx=4)

    def _insert_char(self, ch):
        widget = self.focus_get()
        target = widget if widget in self.targets else self.targets[0]
        target.insert(tk.INSERT, ch)
        target.focus_set()


class Tooltip:
    """
    A small delayed hover tooltip for accessibility -- used mainly on the
    special-character buttons (eth/thorn/wynn/etc.) so a user unfamiliar
    with Old English letterforms can hover (or tab-focus, since it also
    binds FocusIn) to see what the character is and how it sounds.
    """

    def __init__(self, widget, text, delay_ms=350):
        self.widget = widget
        self.text = text
        self.delay_ms = delay_ms
        self._after_id = None
        self._tip = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<FocusIn>", self._schedule, add="+")
        widget.bind("<FocusOut>", self._hide, add="+")

    def _schedule(self, _event=None):
        self._cancel()
        self._after_id = self.widget.after(self.delay_ms, self._show)

    def _cancel(self):
        if self._after_id:
            try:
                self.widget.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None

    def _show(self):
        if self._tip is not None:
            return
        try:
            x = self.widget.winfo_rootx() + 8
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 6
        except tk.TclError:
            return
        self._tip = tk.Toplevel(self.widget)
        self._tip.wm_overrideredirect(True)
        self._tip.wm_geometry(f"+{x}+{y}")
        tk.Label(
            self._tip, text=self.text, bg="#2A2A2E", fg=COLOR_TEXT,
            font=(FONT_FAMILY, 9), padx=8, pady=5, relief="flat",
            highlightthickness=1, highlightbackground=COLOR_ACCENT,
            justify="left", wraplength=220,
        ).pack()

    def _hide(self, _event=None):
        self._cancel()
        if self._tip is not None:
            try:
                self._tip.destroy()
            except Exception:
                pass
            self._tip = None


class ToggleSwitch(tk.Canvas, _BorderFadeMixin):
    """
    A small animated on/off switch (like a native "Settings" toggle) used
    throughout the Settings dialog in place of a plain checkbox, with a
    smooth sliding-knob animation between states.
    """

    WIDTH, HEIGHT = 44, 24

    def __init__(self, master, variable, command=None, **kwargs):
        super().__init__(
            master, width=self.WIDTH, height=self.HEIGHT, bg=COLOR_PANEL,
            highlightthickness=0, cursor="hand2", **kwargs,
        )
        self.variable = variable
        self.command = command
        self._knob_x = self.HEIGHT / 2 if not variable.get() else self.WIDTH - self.HEIGHT / 2
        self._track = self.create_oval(0, 0, 0, 0)  # placeholder, replaced by _draw
        self._draw()
        self.bind("<Button-1>", self._toggle)
        self.bind("<Return>", self._toggle)
        self.bind("<space>", self._toggle)
        self.configure(takefocus=1, highlightthickness=1, highlightbackground=COLOR_BORDER)

    def _draw(self):
        self.delete("all")
        on = self.variable.get()
        track_color = COLOR_ACCENT if on else COLOR_FIELD
        r = self.HEIGHT / 2
        self.create_oval(0, 0, self.HEIGHT, self.HEIGHT, fill=track_color, outline="")
        self.create_rectangle(r, 0, self.WIDTH - r, self.HEIGHT, fill=track_color, outline="")
        self.create_oval(self.WIDTH - self.HEIGHT, 0, self.WIDTH, self.HEIGHT, fill=track_color, outline="")
        knob_r = r - 3
        self.create_oval(
            self._knob_x - knob_r, r - knob_r, self._knob_x + knob_r, r + knob_r,
            fill=COLOR_TEXT, outline="",
        )

    def _toggle(self, _event=None):
        new_val = not self.variable.get()
        self.variable.set(new_val)
        target_x = self.WIDTH - self.HEIGHT / 2 if new_val else self.HEIGHT / 2
        self._animate_knob(target_x)
        if self.command:
            self.command(new_val)

    def _animate_knob(self, target_x, steps=8, duration_ms=140):
        if not ANIMATIONS_ENABLED:
            self._knob_x = target_x
            self._draw()
            return
        start_x = self._knob_x
        step_delay = max(1, duration_ms // steps)

        def _step(i=0):
            t = _ease_in_out(i / steps)
            self._knob_x = start_x + (target_x - start_x) * t
            self._draw()
            if i < steps:
                self.after(step_delay, lambda: _step(i + 1))

        _step(0)


def rounded_rect_points(x1, y1, x2, y2, radius):
    """Return the point list for a rounded-rectangle polygon (smooth=True)."""
    r = radius
    return [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
        x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]


class RoundedPanel(tk.Frame):
    """
    A Frame with a soft rounded-corner background, drawn on an internal
    Canvas that auto-resizes with the widget -- Tkinter has no native
    border-radius, so this fakes the "Google Translate card" look by
    painting a rounded polygon behind a plain content frame that callers
    pack/grid their widgets into (see `.body`).
    """

    def __init__(self, master, bg=None, radius=14, **kwargs):
        super().__init__(master, bg=master["bg"] if "bg" not in kwargs else kwargs.get("bg"), **{k: v for k, v in kwargs.items() if k != "bg"})
        self._radius = radius
        self._panel_bg = bg or COLOR_PANEL
        self._canvas = tk.Canvas(self, highlightthickness=0, bg=self["bg"])
        self._canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self.body = tk.Frame(self, bg=self._panel_bg)
        self.body.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.bind("<Configure>", self._redraw)

    def _redraw(self, _event=None):
        self._canvas.delete("all")
        w = self.winfo_width()
        h = self.winfo_height()
        if w < 4 or h < 4:
            return
        pts = rounded_rect_points(2, 2, w - 2, h - 2, min(self._radius, h / 2, w / 2))
        self._canvas.create_polygon(pts, smooth=True, fill=self._panel_bg, outline=self._panel_bg)


class FadeCard(tk.Frame):
    """
    A Frame representing one row/card in the dictionary list, capable of
    animating itself in (fade/slide open on add) or out (fade on delete)
    rather than appearing/disappearing instantly.

    Because Tkinter widgets don't support real alpha blending, "fade" is
    simulated by interpolating the card's background/foreground colors
    between the page background and the panel color, and "slide open" is
    simulated by animating the widget's height via `pack_propagate` +
    an internal spacer, giving a smooth open effect.
    """

    def __init__(self, master, height=44, **kwargs):
        super().__init__(master, bg=COLOR_PANEL, height=height, **kwargs)
        self.pack_propagate(False)
        self._target_height = height
        self._fade_job = None

    def animate_in(self, duration_ms=220, steps=10):
        """Slide/fade the card open from zero height to its target height."""
        if not ANIMATIONS_ENABLED:
            self.configure(height=self._target_height)
            return
        self.configure(height=1)
        step_delay = max(1, duration_ms // steps)

        def _step(i=0):
            t = _ease_in_out(i / steps)
            h = int(1 + (self._target_height - 1) * t)
            try:
                self.configure(height=h)
            except tk.TclError:
                return
            if i < steps:
                self._fade_job = self.after(step_delay, lambda: _step(i + 1))

        _step(0)

    def animate_out(self, on_complete, duration_ms=180, steps=9):
        """Fade/collapse the card before calling on_complete() to actually
        remove it (e.g. destroy() + refresh the list)."""
        if not ANIMATIONS_ENABLED:
            on_complete()
            return
        step_delay = max(1, duration_ms // steps)
        start_height = self.winfo_height() or self._target_height

        def _step(i=0):
            t = _ease_in_out(i / steps)
            h = int(start_height * (1 - t))
            try:
                self.configure(height=max(h, 0))
            except tk.TclError:
                on_complete()
                return
            if i < steps:
                self.after(step_delay, lambda: _step(i + 1))
            else:
                on_complete()

        _step(0)
