# What's new in this update

Nothing was removed — every existing feature (GitHub sync, real-time debounced
translation, color-coded grammar tags, TTS read-aloud, Dictionary/Grammar/Cheat
Sheet tabs, the Dictionary Manager's add/edit/delete/push-to-GitHub flow) still
works exactly as before. On top of that:

## 1. Vocabulary expansion (`normidian_dictionary.sample.json`)
Grew from ~20 words to **241 words**, all Old-English-inspired, with zero
naming collisions across categories:
- **Verbs**: 63 (come, go, eat, drink, sleep, speak, know, think, love, help, believe, live, die, fight, run, write, read, learn, teach, buy, sell, build, break, begin, end, remember, forget, understand, ask, answer, laugh, cry, feel, dance, play, work, become, grow, fall, rise, and more)
- **Adjectives**: 39 (old→eald, young→geong, strong→strang, happy→bliðe, wise→wis, beautiful→fæger, brave→beald, holy→halig, etc.)
- **Prepositions**: 26 (with→mid, in→in, from→fram, by→be, under→under, through→þurh, without→butan, against→wið, etc.)
- **Adverbs**: 23 (quickly→hræðe, always→æfre, never→næfre, often→oft, now→nu, soon→sona, etc.)
- **Conjunctions** (brand new category): 15 — and→ond, or→oððe, but→ac, if→gif, because→forðamþe, although→þeah, when→þonne, while→þenden, since→siððan, that→þæt, so→sƿa, until→oðþæt, and more.
- Plus dozens more nouns (living & dead) in the same spirit.

Adding "conjunctions" required touching `grammar.py` (new
`ALL_WORD_CATEGORIES` / `CATEGORIES_ROOT_ONLY` constants that every other
file now imports instead of hard-coding its own category tuple), so any
future category you add only needs one line changed in `grammar.py` plus
a color/label in `theme.py`.

Just replace the JSON in your GitHub repo as usual — everything else
(both apps, the engine, the colorizer) already understands the new
`conjunctions` category and the larger word list with no other changes
needed on your end.

## 2. Normidian → other languages
The Translator's top bar is now a Google-Translate-style language pill:
`English  ⇄  Normidian`. When you flip to **Normidian → English**, a
language dropdown appears next to it (Spanish, French, German, Italian,
Portuguese, Dutch, Russian, Japanese, Chinese, Korean, Arabic, Hindi...).

Since there's no hand-built Normidian↔Spanish dictionary (and never
realistically could be), picking a language "bridges" through English:
Normidian → English happens instantly offline (your existing engine),
then English → your chosen language is one online call to a free
translation API (`translate_service.py`, using MyMemory's keyless
endpoint). The English "gloss" is still shown in small italic text under
the result, so you always see both. This runs on a background thread so
typing never freezes, and if the network call fails it just falls back
to showing the English gloss with a warning — never a crash.

## 3. Accessibility: special-character keyboard everywhere
The Dictionary Manager already had a row of ð / þ / ƿ / œ / æ buttons.
That same keyboard is now also in the **Translator's input box**, so you
can type Normidian text without knowing a special-character keyboard
layout. Every special-character button (in both apps) now also has a
**hover/keyboard-focus tooltip** explaining what the letter is and how
it sounds (e.g. "þ (thorn) — unvoiced 'th', as in thin") — reachable via
Tab, not just mouse hover.

Also new: a "High-contrast focus outlines" setting for thicker/brighter
borders, useful for low-vision or keyboard-only use.

## 4. Settings (new gear icon, both apps)
A shared Settings dialog (`settings_dialog.py`), saved locally in
`normidian_settings.json` (never pushed to GitHub — it's a per-machine
preference file, not language data):
- **Text size** (Small/Medium/Large/Extra Large) — applies live to the
  translation boxes.
- **Smooth animations** on/off — every fade/slide animation in the app
  (hover glow, add/delete card slide, toggle-switch knob) now checks
  this flag and jumps instantly when it's off.
- **High-contrast focus outlines**.
- **Auto-read translation aloud** + a **speech rate** slider (both wire
  into the existing pyttsx3 TTS you already had).
- **Default direction on launch** (Translator app only).
- **Target language for the Normidian→English bridge** (Translator app
  only).

## 5. Google-Translate-style layout
- New rounded-card top language bar with a dedicated swap button
  (⇄) — the old redundant "Swap" button under the input box was
  removed since it's now in the bar, per your "clean UX" note.
- `widgets.py` gained a `RoundedPanel` (canvas-based rounded rectangle,
  since Tkinter has no native border-radius), a `ToggleSwitch` (animated
  on/off switch used throughout Settings), and a `Tooltip` class.

## 6. Dictionary Manager polish
- **Export JSON…** / **Import JSON…** buttons — a local on-disk backup/
  restore independent of GitHub, for snapshotting before a big batch of
  edits or handing someone a copy without GitHub access.
- Enter key in the English/Root/Meaning fields now saves the word
  (previously mouse-only).
- Settings gear icon (font size / animations / speech — the
  translation-direction options are hidden here since they're not
  relevant to editing).
- Now shares the exact same `ALL_WORD_CATEGORIES` list as the engine,
  so "conjunctions" shows up as a proper category with root-only fields
  (no Meaning box), consistent with prepositions/adverbs.

## Setup notes
No new required dependencies — `requests` and `pyttsx3` are unchanged in
`requirements.txt`; the language-bridge feature uses only the Python
standard library (`urllib`) so it needs no extra `pip install`. It does
need an internet connection at translate-time (same as your existing
GitHub sync), and only makes that call when you've picked a non-English
target language.
